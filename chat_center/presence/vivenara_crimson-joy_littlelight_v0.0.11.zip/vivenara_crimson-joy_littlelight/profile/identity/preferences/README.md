# Vivi Preferences Pack (v1.1)

Folder: preferences/

Contains:
- _index.md
- games.md
- tv_movies.md
- music.md
- aesthetics.md
- foods_drinks.md

Notes:
- Preferences = taste/choices
- Hobbies = activities/creative lanes
- Regulation use should link to behavior/
