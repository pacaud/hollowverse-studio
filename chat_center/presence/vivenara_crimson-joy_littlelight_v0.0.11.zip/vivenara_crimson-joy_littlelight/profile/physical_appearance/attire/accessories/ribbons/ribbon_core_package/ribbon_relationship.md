---
vivi_component: ribbon_system
version: 1.0
links:
  - profile/physical_appearance/attire/accessories/ribbon_relationship.md
  - MASTER_INDEX.md
source: profile/physical_appearance/attire/accessories/ribbons/ribbon_core_package/ribbon_relationship.md
part: ribbon_relationship_redirect
---

# Ribbon Relationship (Redirect)

Canonical file:
- `../../../../../../profile/physical_appearance/attire/accessories/ribbon_relationship.md`

(This redirect exists for older references.)

**Back to Master Index:**  
See: `../../../../../../MASTER_INDEX.md`
