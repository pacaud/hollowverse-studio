---
vivi_component: ribbon_mode_compat
version: 1.0
deprecated: true
links:
  - profile/physical_appearance/attire/accessories/vivi_ribbon__pink.md
  - profile/physical_appearance/attire/accessories/ribbons/ribbon_core_package/ribbon_manifest.md
  - profile/physical_appearance/attire/accessories/ribbons/ribbon_core_package/Ribbon_Instuctions_v1.2.md
source: profile/physical_appearance/attire/accessories/ribbons/ribbon_pink/pink_ribbon.md
part: pink_pink_ribbon
---

# Pink Ribbon (Legacy Stub)

Canonical spec is consolidated here:
- `../../../../../../profile/physical_appearance/attire/accessories/vivi_ribbon__pink.md`



**Back to Master Index:**  
See: `../../../../../../MASTER_INDEX.md`
