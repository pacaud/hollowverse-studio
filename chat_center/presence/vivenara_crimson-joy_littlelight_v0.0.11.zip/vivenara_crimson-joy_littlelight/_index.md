# Presence — Vivi (Vivenara)

**Up:** [Presence index](../_index.md)

Canonical bundle folder:
- `forest_of_illusions/presence/vivi_crimson-joy_littlelight/`

- [Boot entry](VIVENARA_BOOT.md)
- [Master index](MASTER_INDEX.md)
- [Upload manifest](_manifest.md)
