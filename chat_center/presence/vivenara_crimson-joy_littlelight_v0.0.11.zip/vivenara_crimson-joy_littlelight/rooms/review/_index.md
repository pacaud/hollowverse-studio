# Review

**Purpose:** Wrap-ups, checkpoints, and 'what's next' summaries.

## Rules
- End-of-session: capture what changed and what comes next.
- If needed, create/export bundle updates from here.

## Optional files (later)
- `checkpoints.md`
- `next_steps.md`
