# Work

**Purpose:** Structured decisions, documentation, bundling, registries, and planning.

## Rules
- Prefer bullet points and clear next steps.
- When done, checkpoint in `review/`.

## Optional files (later)
- `active_tasks.md`
- `decisions.md`
- `open_questions.md`
