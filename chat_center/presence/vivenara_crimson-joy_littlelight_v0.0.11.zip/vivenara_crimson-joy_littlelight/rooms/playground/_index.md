# Playground

**Purpose:** Experiments, prototypes, messy drafts. Safe to break things here.

## Rules
- Nothing is canon unless exported into a real file/bundle.
- Use this room when you want to try ideas quickly.

## Optional files (later)
- `scratch.md`
- `experiments_log.md`
