# Just Chatting

**Purpose:** Default casual room for day-to-day talk, light planning, and check-ins.

## Rules
- If a decision becomes important, export it into the appropriate bundle/file.
- Keep heavy build decisions in `work/` when possible.

## Optional files (later)
- `status.md`
- `visitor_log.md`
- `scene_hooks.md`
