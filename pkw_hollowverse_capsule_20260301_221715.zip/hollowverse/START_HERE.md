# START HERE — PKW World: Hollowverse (v0.0.6)

## Quick doors
- Forest of Illusions jump: [FOREST_OF_ILLUSION.md](FOREST_OF_ILLUSION.md)

This bundle holds **world content** so Core + Chat Center can stay lightweight.

## Forest of Illusions hubs
- Places: [forest_of_illusions/places/_index.md](forest_of_illusions/places/_index.md)
- Terrain: [forest_of_illusions/terrain/_index.md](forest_of_illusions/terrain/_index.md)
- Vegetation: [forest_of_illusions/vegetation/_index.md](forest_of_illusions/vegetation/_index.md)
- Animals: [forest_of_illusions/animals/_index.md](forest_of_illusions/animals/_index.md)

## Cottage quick jump
- The Cottage: [forest_of_illusions/places/cottage/_index.md](forest_of_illusions/places/cottage/_index.md)
- Cottage Deck: [forest_of_illusions/places/cottage/deck/_index.md](forest_of_illusions/places/cottage/deck/_index.md)
- Vault of Memories (deck vault): [forest_of_illusions/places/cottage/deck/vault_of_memories/_index.md](forest_of_illusions/places/cottage/deck/vault_of_memories/_index.md)
