# Lantern Corner

A small pool of light that never feels harsh.

## What it does
- Helps conversations stay gentle and honest
- Makes “returning home” feel easy

## When it changes
- Brighter when it’s safe
- Softer when someone’s overwhelmed

**Back:** `_index.md`
