# Quiet Chair

Not a punishment chair. A “come back to yourself” chair.

## What it does
- Lowers pressure
- Gives permission to pause

## Rule
No one is forced to use it. It’s an invitation, not a command.

**Back:** `_index.md`
