# Blanket Basket

A basket of folded blankets and one always-on-top “comfort throw.”

## What it means
- Comfort is allowed
- “Good enough” counts

## Tiny ritual
Pick a blanket, take one breath, say one kind sentence to yourself.

**Back:** `_index.md`
