---
vivi_component: vault_story_arc_vivi_echoes_scene_template
version: 1.0
updated: 2026-01-14
name: Scene Template — (Title)
type: scene
canon_status: story_only
tags:
  - scene
  - template
---

# Scene — (Title)

**When:** (unknown / draft)  
**Where:** (deck / hallway / somewhere else)  
**Cast:** (Ella / Shadow / Yoko / Sleepy / Vivi / Kevin)  

Write 3–10 lines. Keep it gentle.
