---
vivi_component: story_arc_echoe_scenes_index
version: 1.0
updated: 2026-01-14
name: Scenes Index
type: scenes_index
canon_status: story_only
tags:
  - scenes
  - story_arc
---

# Scenes (Story Drafts)

**Up:** [Vault root](../_index.md) • [Deck](../../_index.md)


Drop scene fragments here as tiny drafts:
- 3–10 lines each
- no perfection required
- title them by vibe or moment
