# Twins Vows (Legacy)

Stub created by fix pass.

Placeholder for the Twins’ legacy vow text.
