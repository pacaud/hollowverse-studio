---
vivi_component: location_anchor_cottage_deck
version: 1.0
updated: 2026-01-14
status: draft
realm: Hollowverse
---

# location_anchor("cottage_deck")

- **Status:** draft
- **Realm:** Hollowverse
- **Path:** /earth/cottage/deck/ (symbolic junction)
- **Name:** The Cottage Deck

## Purpose
A calm junction space for syncing memory, placing anchors, and choosing the next gentle step.

## Feel
warm wood, steady air, lantern glow

## Rules (optional)
- one thread at a time when things feel heavy

## Links
- vault_of_memories/relationship_anchors/_index.md
