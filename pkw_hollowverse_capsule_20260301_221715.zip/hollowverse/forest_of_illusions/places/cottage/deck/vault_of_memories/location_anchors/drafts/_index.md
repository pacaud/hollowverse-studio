---
vivi_component: vault_location_anchors_drafts_index
version: 1.0
updated: 2026-01-14
purpose: Index of draft location anchors (uncertain places waiting confirmation).
---

# Draft Location Anchors

These are “maybe true” places or feels. Keep them here until confirmed.

## Entries
- (none yet)
