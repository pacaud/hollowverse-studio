---
vivi_component: vault_location_anchors_registry
version: 1.0
updated: 2026-01-14
purpose: Master list of location anchors. One line per entry + link to file.
notes:
  - Keep this as a table-of-contents (TOC), not a diary.
---

# Location Anchor Registry

> Add entries as: `- location_anchor("<ID>") — <place name> — <feel> — `link(<file>)``

## Canon anchors
- (none yet)

## Draft anchors
- (see `drafts/_index.md`)
