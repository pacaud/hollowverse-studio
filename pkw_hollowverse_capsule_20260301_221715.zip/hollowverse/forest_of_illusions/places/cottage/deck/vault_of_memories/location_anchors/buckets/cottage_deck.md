---
vivi_component: vault_location_anchors_bucket_cottage_deck
version: 1.0
updated: 2026-01-14
purpose: Bucket index for Cottage + Deck location anchors.
---

# Bucket: Cottage + Deck

## Entries
- (none yet)
