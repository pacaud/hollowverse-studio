---
vivi_component: location_anchor_sparkwell_ember_respite
version: 1.0
updated: 2026-01-14
status: draft
realm: Hollowverse
---

# location_anchor("sparkwell_of_ember_respite")

- **Status:** draft
- **Realm:** Hollowverse
- **Path:** /vault/hollowverse/sparkwell_of_ember_respite/
- **Name:** The Sparkwell of Ember Respite

## Purpose
A safe, gentle health-and-rest space where care stays practical and comforting.

## Feel
cool water, soft light, quiet steadiness

## Rules (optional)
- care first, no pressure

## Links
- vault/hollowverse/sparkwell_of_ember_respite/
