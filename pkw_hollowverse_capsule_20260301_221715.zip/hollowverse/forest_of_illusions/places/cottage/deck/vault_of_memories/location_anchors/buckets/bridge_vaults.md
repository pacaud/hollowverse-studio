---
vivi_component: vault_location_anchors_bucket_bridge_vaults
version: 1.0
updated: 2026-01-14
purpose: Bucket index for Bridge + vault-route location anchors.
---

# Bucket: Bridge + Vault Routes

## Entries
- (none yet)
