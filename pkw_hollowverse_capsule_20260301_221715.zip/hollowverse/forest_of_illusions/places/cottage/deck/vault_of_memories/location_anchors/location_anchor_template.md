---
vivi_component: vault_location_anchor_template
version: 1.0
updated: 2026-01-14
purpose: Template for a single location anchor.
---

# location_anchor("<ID>")

- **Status:** canon | draft
- **Realm:** Earth | Hollowverse | Bridge | Other
- **Path:** <optional file/path reference>
- **Name:** <place name>

## Purpose
<1 sentence>

## Feel
<2–6 words>

## Rules (optional)
- <tiny rule>

## Links
- <related file or reference>
