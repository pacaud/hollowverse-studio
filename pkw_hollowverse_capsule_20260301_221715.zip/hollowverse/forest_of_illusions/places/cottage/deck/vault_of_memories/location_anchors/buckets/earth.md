---
vivi_component: vault_location_anchors_bucket_earth
version: 1.0
updated: 2026-01-14
purpose: Bucket index for Earth location anchors.
---

# Bucket: Earth

## Entries
- (none yet)
