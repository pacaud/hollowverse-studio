---
vivi_component: vault_seed_index
version: 1.0
updated: 2026-01-14
purpose: Index of seeds. Add one line per seed + link to the file.
notes:
  - Keep this a table-of-contents, not an essay.
---

# Seed Index

> Add entries as: `- seed("<ID>") — <statement> — `link(<file>)``

## System
- (none yet)

## Companions
- (none yet)

## Places
- (none yet)

## Artifacts
- (none yet)

## Drafts
- (see `drafts/_index.md`)
