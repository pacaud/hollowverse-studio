---
vivi_component: vault_seeds_bucket_system
version: 1.0
updated: 2026-01-14
purpose: Bucket index for system seeds.
---

# Bucket: System Seeds

## Entries
- (none yet)
