---
vivi_component: vault_seeds_bucket_artifacts
version: 1.0
updated: 2026-01-14
purpose: Bucket index for artifacts + items seeds.
---

# Bucket: Artifacts Seeds

## Entries
- (none yet)
