---
vivi_component: vault_seeds_bucket_places
version: 1.0
updated: 2026-01-14
purpose: Bucket index for places + locations seeds.
---

# Bucket: Places Seeds

## Entries
- (none yet)
