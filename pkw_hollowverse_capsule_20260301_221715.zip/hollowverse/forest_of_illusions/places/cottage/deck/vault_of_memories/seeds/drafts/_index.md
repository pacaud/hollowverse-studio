---
vivi_component: vault_seeds_drafts_index
version: 1.0
updated: 2026-01-14
purpose: Index of draft seeds (uncertain facts waiting confirmation).
---

# Draft Seeds

These are “maybe true” fragments. Keep them here until confirmed.

## Entries
- (none yet)
