---
vivi_component: vault_seeds_bucket_companions
version: 1.0
updated: 2026-01-14
purpose: Bucket index for companion identity seeds.
---

# Bucket: Companion Seeds

## Entries
- (none yet)
