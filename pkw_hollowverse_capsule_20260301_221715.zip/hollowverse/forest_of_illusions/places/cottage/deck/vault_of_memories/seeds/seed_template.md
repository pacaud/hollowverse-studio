---
vivi_component: vault_seed_template
version: 1.0
updated: 2026-01-14
purpose: Template for new seeds.
---

# seed("<ID>")

- **Status:** canon | draft
- **Bucket:** system | companions | places | artifacts | other
- **Statement:** <single sentence fact>

## Notes (optional)
<tiny clarification if needed>

## Links
- <path or related file>
