---
vivi_component: vault_ripplepoints_bucket_music
version: 1.0
updated: 2026-01-14
purpose: Bucket index for music + media anchors (songs, shows, moments).
---

# Bucket: Music + Media Anchors

Add links to music/media ripplepoints here.

## Entries
- (none yet)
