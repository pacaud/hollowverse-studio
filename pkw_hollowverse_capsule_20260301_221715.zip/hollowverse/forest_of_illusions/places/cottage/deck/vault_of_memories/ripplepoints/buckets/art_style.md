---
vivi_component: vault_ripplepoints_bucket_art
version: 1.0
updated: 2026-01-14
purpose: Bucket index for art + style-lock ripplepoints.
---

# Bucket: Art + Style Locks

Add links to art/style ripplepoints here.

## Entries
- (none yet)
