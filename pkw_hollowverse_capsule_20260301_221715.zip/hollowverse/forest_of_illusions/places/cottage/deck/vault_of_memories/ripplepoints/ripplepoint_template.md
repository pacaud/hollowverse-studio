---
vivi_component: vault_ripplepoint_template
version: 1.0
updated: 2026-01-14
purpose: Template for new ripplepoints.
---

# ripplepoint("<ID>")

- **Date:** YYYY-MM-DD
- **Bucket:** system | companions | art | music | business | other
- **Status:** draft | canon
- **Name:** <short human title>

## What happened
<1–3 sentences>

## Why it matters
<1–2 sentences>

## What changed (if anything)
- <bullet list, optional>

## Links
- <path or related file>
- <path or related file>
