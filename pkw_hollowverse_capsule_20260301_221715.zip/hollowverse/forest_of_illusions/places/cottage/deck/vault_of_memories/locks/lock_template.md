---
vivi_component: vault_lock_template
version: 1.0
updated: 2026-01-14
purpose: Template for new locks.
---

# lock("<ID>")

- **Status:** canon | draft
- **Bucket:** visual_style | safety | behavior | system | content | other
- **Rule:** <single sentence or short bullet rule>
- **Scope:** chat | files | art | web | build | all

## Trigger
<When does this lock apply?>

## Enforcement
<What to do to obey the lock?>

## Exceptions (optional)
<Only if truly needed>

## Links
- <source-of-truth file or place>
