---
vivi_component: vault_locks_bucket_visual
version: 1.0
updated: 2026-01-14
purpose: Bucket index for visual style locks (branding, art style, UI constraints).
---

# Bucket: Visual Style Locks

## Entries
- lock("vivi_visual_style_lock") — [vivi_visual_style_lock.md](../visual_style/vivi_visual_style_lock.md)
