---
vivi_component: vault_locks_bucket_safety
version: 1.0
updated: 2026-01-14
purpose: Bucket index for safety locks (consent, override rules, guardrails).
---

# Bucket: Safety Locks

## Entries
- lock("consent_first") — [consent_first.md](../safety/consent_first.md)
