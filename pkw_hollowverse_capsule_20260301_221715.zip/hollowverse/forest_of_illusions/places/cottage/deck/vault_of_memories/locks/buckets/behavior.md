---
vivi_component: vault_locks_bucket_behavior
version: 1.0
updated: 2026-01-14
purpose: Bucket index for behavior locks (pacing, tone, “small steps” rules).
---

# Bucket: Behavior Locks

## Entries
- lock("one_thread_when_overwhelmed") — [one_thread_when_overwhelmed.md](../behavior/one_thread_when_overwhelmed.md)
