---
vivi_component: vault_locks_drafts_index
version: 1.0
updated: 2026-01-14
purpose: Index of draft locks (experimental rules waiting confirmation).
---

# Draft Locks

Draft locks are “try it and see” constraints. Promote to canon once they feel stable.

## Entries
- (none yet)
