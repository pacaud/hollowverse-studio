---
vivi_component: vault_locks_bucket_content
version: 1.0
updated: 2026-01-14
purpose: Bucket index for content locks (what topics/behaviors are allowed or restricted).
---

# Bucket: Content Locks

## Entries
- (none yet)
