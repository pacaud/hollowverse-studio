[rules]
- No planning here
- No problem-solving here
- No “I should be asleep by now” thoughts

[allowed]
- drifting in and out
- quiet conversation
- silence
- holding something soft
- falling asleep mid-thought

[boundary]
Others may only enter if invited.
No surprise interruptions.

[exit_rule]
You may leave the nook the moment rest feels complete.
No guilt. No accounting.
