[scene_hooks]
- "The curtain shifts slightly as you lie down."
- "The light is low enough that time blurs."
- "You wake up unsure how long it’s been."
- "Someone left a folded blanket here."
- "The cabin is quiet, but not empty."

[tone_tags]
- rest
- safety
- gentleness
- night
