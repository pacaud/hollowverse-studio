[layout]
- Size: small (nest-like)
- Bed: daybed or low bed against the wall
- Position: tucked into a corner or alcove
- Separation: curtain, shelf, or half wall (not a door)

[key_elements]
- soft bedding
- one pillow you always return to
- small side surface (book, phone, water)
- low, warm light source

[sensory_notes]
- Sound: muffled cabin sounds are okay
- Light: indirect, never harsh
- Air: still, slightly warm

[spatial_rule]
If it feels too open, add softness.
If it feels too closed, open the curtain a little.
