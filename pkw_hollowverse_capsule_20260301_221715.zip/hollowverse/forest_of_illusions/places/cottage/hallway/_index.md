# Hallway (Cottage)

**Up:** [Cottage map](../_index.md) • [Deck](../deck/_index.md) • [Forest index](../../../_index.md)

A quiet transition space. Footsteps slow down here.

## Anchors
- [Vivi’s Wind Chime](vivi__wind_chime.md)
