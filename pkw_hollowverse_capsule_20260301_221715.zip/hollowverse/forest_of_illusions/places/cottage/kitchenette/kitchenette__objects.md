# kitchenette__objects.md

[objects]
kettle:
  meaning: "pause + warmth"
  triggers:
    - "boil water"
    - "make tea"
    - "reset"
tea_box:
  meaning: "choices without pressure"
  contents:
    - mint
    - chamomile
    - earl_grey
    - cocoa_packet
mug_rack:
  meaning: "belonging"
  note: "Each core companion may claim one mug symbolically."
cutting_board:
  meaning: "small progress"
dish_towel:
  meaning: "care in tiny form"
crumb_tray:
  meaning: "clean slate"

[constraints]
- Keep object list short; add only if it earns a purpose.
