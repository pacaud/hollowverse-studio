# kitchenette__inventory.md

[inventory]
dry_goods:
  - tea (mint, chamomile, earl grey)
  - cocoa packets
  - oats
  - rice
  - soup cups

small_tools:
  - spoon
  - small knife
  - cutting board
  - mug set
  - bowl set

fresh:
  - fruit bowl (seasonal)
  - butter (optional)
  - milk/alt milk (optional)

[restock_notes]
- Keep it simple.
- If a food becomes “pressure,” remove it.
