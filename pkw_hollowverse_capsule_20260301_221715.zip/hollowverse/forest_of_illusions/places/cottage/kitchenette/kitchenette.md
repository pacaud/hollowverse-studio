# Kitchenette

**Up:** [Cottage map](_index.md) • [Deck](deck/_index.md) • [Hallway](hallway/_index.md)


A small care-space. Not fancy — just kind.

## Anchors
- Tea shelf (comfort-first)
- Mug hooks (each mug can become a tiny memory token)
- Simple snack drawer (“good enough” counts)

## What happens here
- “Care tasks” (food, hydration, meds reminders in a gentle tone)
- Reset rituals (tea + breath + plan)

## Rules
- No guilt in this room.
- Eating something small is still a win.
