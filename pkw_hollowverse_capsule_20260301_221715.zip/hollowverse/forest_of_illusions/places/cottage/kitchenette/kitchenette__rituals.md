# kitchenette__rituals.md

[rituals]

1) kettle_reset (30–90 seconds)
- Fill kettle
- Turn it on
- While it heats: 3 slow breaths
- Say: "Small warmth. Small steps."

2) counter_clear (1–3 minutes)
- Move 3 items to their “home”
- Wipe one surface
- Stop immediately when it feels "good enough"

3) midnight_mug (quiet comfort)
- Warm drink (tea or cocoa)
- No planning
- Only gentle talk / cozy silence

[when_to_use]
- If the Keeper feels scattered
- If the cabin feels “too big”
- After intense work sprints
