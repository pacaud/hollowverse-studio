# Kitchenette (Cottage)

**Up:** [Cottage map](../_index.md) • [Sitting Room](../sitting_room/_index.md) • [Forest index](../../../_index.md)

## Start here
- [Kitchenette — Room Page](kitchenette__README.md)

## Files
- [Layout](kitchenette__layout.md)
- [Objects](kitchenette__objects.md)
- [Rituals](kitchenette__rituals.md)
- [Inventory](kitchenette__inventory.md)
