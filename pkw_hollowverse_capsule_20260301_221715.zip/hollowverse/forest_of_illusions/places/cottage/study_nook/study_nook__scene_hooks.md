[scene_hooks]
- "The desk lamp clicks on."
- "You write one clean sentence."
- "The room feels quieter when you sit."
- "A page is filled, slowly."
- "You stop before exhaustion."

[tone_tags]
- focus
- clarity
- gentle-work
- intentional
