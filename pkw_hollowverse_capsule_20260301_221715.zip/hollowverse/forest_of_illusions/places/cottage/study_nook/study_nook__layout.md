[layout]
- Size: small (desk + chair + shelf)
- Desk: facing wall or window (no room-facing desk)
- Chair: comfortable but upright
- Shelf: minimal, eye-level

[key_elements]
- desk surface (mostly clear)
- chair
- lamp (focused, warm-neutral)
- notebook or tablet stand
- small object for grounding

[sensory_notes]
- Light: brighter than sitting room, softer than office
- Sound: quiet, steady, low distraction
- Visuals: minimal, no clutter

[spatial_rule]
If clutter appears, pause before continuing.
