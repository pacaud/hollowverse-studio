[tools]
primary:
  - notebook
  - pen or pencil
  - keyboard
  - monitor (optional)
secondary:
  - timer (gentle, non-alarm)
  - water
  - reference book

[tool_ethics]
- Tools serve the task, not the ego
- Fewer tools = clearer focus

[maintenance]
- Clear desk at end of session
- Leave one intentional item out
