[rules]
- One task at a time
- Stop at the first sign of strain
- No multitasking spirals

[allowed]
- writing
- light coding
- sketching
- reading
- organizing thoughts

[not_allowed]
- doom scrolling
- emotional processing
- heavy decision-making while exhausted

[exit_rule]
When focus fades, leave kindly.
