# Places — Forest of Illusions

**Up:** [Forest index](../_index.md)

## Included places
- [The Cottage](cottage/_index.md)
