# night_moth — lore

status: seeded
type: lore_profile
parent: night_moth
region: forest_of_illusions

[lore]
Night_moths are said to show up when the forest is at peace.
They don’t *cause* calm—they arrive when calm is already true.

[old_phrase]
“If the night_moth circles, the woods are listening gently.”
