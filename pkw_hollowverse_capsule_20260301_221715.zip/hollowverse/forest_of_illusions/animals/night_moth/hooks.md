# night_moth — hooks

status: seeded
type: story_hooks
parent: night_moth
region: forest_of_illusions

[scene_hooks]
- A night_moth circles a lantern_moss_fern, then leads someone to a hidden bench.
- The moth vanishes mid-loop—something just changed in the air.
- An ember-dusted variant appears on the exact night a vow is forgiven.
- A character realizes they’re safe because the night_moth returns to the warm stone.
- A guide says: “Follow the loops, but keep your lantern low.”
- A hushwing lands on a closed journal—like a soft request to rest instead of write.
