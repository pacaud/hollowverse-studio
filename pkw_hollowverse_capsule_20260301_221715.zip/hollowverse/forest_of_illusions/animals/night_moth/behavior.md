# night_moth — behavior

status: seeded
type: behavior_profile
parent: night_moth
region: forest_of_illusions

[behavior]
- circles lantern_moss_fern at night, as if checking the glow
- rests on warm stones after drifting through mist pockets
- avoids harsh light; prefers low lanterns and moonlit shade

[signals]
- slow, wide loops = calm air / safe night
- quick darting + vanishing = something unsettled nearby
