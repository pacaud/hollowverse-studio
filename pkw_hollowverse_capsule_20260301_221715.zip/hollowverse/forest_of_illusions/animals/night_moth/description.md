# night_moth — description

status: seeded
type: creature_description
parent: night_moth
region: forest_of_illusions

[description]
A large moth with velvety wings that catch moonlight softly.
It reads as “quiet” even when it’s moving.

[scale]
- wingspan: hand-wide to forearm-wide (varies)
- presence: noticeable, but never startling

[see_also]
- sensory profile: sensory.md
- behavior: behavior.md
