# night_moth — use

status: seeded
type: use_profile
parent: night_moth
region: forest_of_illusions

[use]
- evening ambience
- night scenes
- “the night is safe” marker

[scene_moves]
- a lantern is lowered instinctively when a night_moth passes
- a character follows its slow loops toward a quiet rest spot
