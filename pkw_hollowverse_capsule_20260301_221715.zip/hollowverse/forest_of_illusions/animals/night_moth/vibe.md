# night_moth — vibe

status: seeded
type: vibe_profile
parent: night_moth
region: forest_of_illusions

[vibe_keywords]
- quiet wonder
- night-soft
- lantern calm
- gentle attention
- “safe to exhale”

[emotional_tone]
Night_moth energy is subtle—like noticing the sky is friendly tonight.
