# mist_fox

status: seeded
type: animal
region: forest_of_illusions

[vibe]
curious, respectful, quiet

[description]
A fox with a pale coat that blends easily into fog.
Moves slowly, as if listening more than watching.

[behavior]
- appears near mist_loop_trail
- keeps a gentle distance
- leaves neat paw prints

[lore]
- Said to guide wanderers without leading them.

[use]
- discovery scenes
- soft curiosity
