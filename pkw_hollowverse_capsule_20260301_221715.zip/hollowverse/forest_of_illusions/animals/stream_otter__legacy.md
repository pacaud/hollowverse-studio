# stream_otter

status: seeded
type: animal
region: forest_of_illusions

[vibe]
playful calm, water joy

[description]
A sleek otter that lives along the cottage_stream.
Often seen rolling pebbles or floating quietly.

[behavior]
- active in morning light
- splashes softly
- curious but friendly

[lore]
- Represents ease and simple joy.

[use]
- stream-side moments
- lighthearted scenes
