# ribbon_deer

status: seeded
type: animal
region: forest_of_illusions

[vibe]
graceful, safe passage

[description]
A deer with faint ribbon-like markings along its flanks.
Appears briefly at clearing edges.

[behavior]
- pauses before crossing paths
- makes eye contact, then leaves

[lore]
- Seen as a sign of safe movement through the forest.

[use]
- transition moments
- calm awe
