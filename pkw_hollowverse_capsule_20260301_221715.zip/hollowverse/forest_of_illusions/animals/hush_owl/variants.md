# hush_owl — variants

status: rumor
type: variants
parent: hush_owl
region: forest_of_illusions
[baseline]
Hush Owl is rumor-tier: more felt than seen.

[whispered_variants]
- silvercall hush_owl — call carries farther, still soft
- branchshadow hush_owl — only a silhouette against moonlight
