# hush_owl — behavior

status: rumor
type: behavior_profile
parent: hush_owl
region: forest_of_illusions
- appears only in deep night
- never seen clearly
