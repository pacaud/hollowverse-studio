# hush_owl — use

status: rumor
type: use_profile
parent: hush_owl
region: forest_of_illusions
[use]
- scene marker for “deep night hush” moments
- a gentle warning: slow down; rest may be nearby

[notes]
Not a tool-creature. Treated as presence + omen, not utility.
