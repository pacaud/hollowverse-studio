# hush_owl — hooks

status: rumor
type: story_hooks
parent: hush_owl
region: forest_of_illusions
[scene_hooks]
- The call arrives and the forest goes quiet—then you notice a hidden rest spot.
- Someone follows the hush and finds a trail they swear wasn’t there before.
- The owl’s presence becomes a nightly boundary: “don’t push past this point.”
- A companion interprets the hush as permission to finally sleep.
