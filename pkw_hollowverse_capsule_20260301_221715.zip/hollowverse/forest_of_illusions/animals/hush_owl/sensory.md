# hush_owl — sensory

status: rumor
type: sensory_profile
parent: hush_owl
region: forest_of_illusions
[sound]
- a call that seems to lower everything else

[sight]
- rarely seen clearly; often just a shape in the canopy

[air]
- deep-night cool, like the forest is holding its breath
