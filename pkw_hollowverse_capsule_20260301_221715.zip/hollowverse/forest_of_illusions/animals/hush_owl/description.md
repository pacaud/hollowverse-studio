# hush_owl — description

status: rumor
type: animal_description
parent: hush_owl
region: forest_of_illusions
An owl rarely seen, more often felt.
Its call is said to silence other sounds.
