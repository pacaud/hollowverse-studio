# hush_owl — lore

status: rumor
type: lore_profile
parent: hush_owl
region: forest_of_illusions
- Some say it watches over rest.
