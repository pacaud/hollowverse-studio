# hush_owl — growth

status: rumor
type: animal_growth
parent: hush_owl
region: forest_of_illusions
[sighting_window]
- deep night only

[life_cycle_notes]
- kept as rumor until observed; details unknown
