# hush_owl — vibe

status: rumor
type: vibe_profile
parent: hush_owl
region: forest_of_illusions
[vibe]
watchful quiet, deep night
