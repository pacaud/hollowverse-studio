status: seeded
type: lore_profile
parent: stream_otter
region: forest_of_illusions

[lore]
- Represents ease and simple joy.
- Old walkers say seeing a stream otter means the forest is “still safe enough to play.”

[meaning]
If the stream otter shows up during a hard day, it’s the world’s gentle nudge:
“Breathe. The water is still here.”
