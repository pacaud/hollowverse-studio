status: seeded
type: use_profile
parent: stream_otter
region: forest_of_illusions

[use]
- stream-side moments
- lighthearted scenes after heavy conversations
- “follow the water” navigation beats
- companion comfort: a living reminder that joy can be simple

[scene_pairings]
- cottage_stream: terrain/water/cottage_stream.md
- warmstone bench: terrain/landmarks/warmstone_bench.md
