status: seeded
type: description
parent: stream_otter
region: forest_of_illusions

[description]
A sleek otter that lives along the cottage_stream.
Often seen rolling pebbles, floating quietly, or slipping under a bank-root and vanishing like a joke.

[habitat]
- cottage_stream bends and shallow pools
- mossy banks with flat stones for sun-warming
- under-root hideouts near quiet water

[notes]
If you see one, you’re usually near a safe stretch of stream.
