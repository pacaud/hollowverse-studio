status: seeded
type: behavior_profile
parent: stream_otter
region: forest_of_illusions

[behavior]
- active in morning light
- splashes softly (play, not warning)
- curious but friendly
- rolls pebbles like little puzzles
- floats on its back when the day is calm

[interaction]
- approaches slowly if you sit still
- retreats immediately if voices rise
- may “show the safe path” by surfacing ahead and watching you follow

[boundaries]
Do not chase. If it dives, let it go—if it wants you nearby, it comes back on its own.
