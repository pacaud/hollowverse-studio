status: seeded
type: story_hooks
parent: stream_otter
region: forest_of_illusions

[scene_hooks]
- A stream otter drops a single smooth pebble at someone’s feet—like a gift.
- The otter surfaces at every turn, “guiding” a lost traveler along the water.
- A pebble stash is found beside a note that shouldn’t be there.
- The otter vanishes for weeks; when it returns, the stream has changed.
- Two people watch the same otter and both feel like it chose them.
- A moonfloat variant appears the night someone finally comes home.
- The otter refuses to approach—until voices soften.
- A kit gets stuck in reeds; rescuing it changes the mood of the whole clearing.
