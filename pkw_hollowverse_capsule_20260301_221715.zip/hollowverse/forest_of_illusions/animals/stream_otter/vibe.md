status: seeded
type: vibe_profile
parent: stream_otter
region: forest_of_illusions

[vibe_keywords]
- playful calm
- water joy
- easy breath
- pebble games
- “it’s okay to just be here”

[emotional_effect]
Stream Otter carries the feeling of uncomplicated joy.
Not hype—more like the relief of realizing you’re allowed to relax.

[tempo]
- onset: quick (you notice them right away)
- peak: steady, lighthearted
- fade: gentle; lingers as “better mood”
