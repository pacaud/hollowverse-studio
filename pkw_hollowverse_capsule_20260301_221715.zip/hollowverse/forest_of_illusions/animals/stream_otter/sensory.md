status: seeded
type: sensory_profile
parent: stream_otter
region: forest_of_illusions

[visual]
- coat: dark-brown with a wet sheen; lighter around the face
- movement: smooth, fast, then suddenly still
- eyes: bright and curious (more observant than intense)

[sound]
- soft water splashes (never aggressive)
- little chuffs when excited
- pebble clicks during play

[scent]
- clean river water
- damp moss from the bank

[touch]
- fur: dense and slick when wet, plush when dry
- paws: small, quick, careful on stones
