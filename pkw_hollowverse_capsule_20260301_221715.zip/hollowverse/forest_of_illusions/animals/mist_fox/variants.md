# mist_fox — variants

status: seeded
type: variants
parent: mist_fox
region: forest_of_illusions

[baseline]
Pale coat, slow movement, quiet curiosity.

[known_variants]
- dewglint mist fox
  - look: tiny dew sparkle along the ears at dawn
  - where: stream bends, fog pockets
- duskshadow mist fox
  - look: slightly darker tail and paws
  - where: twilight trails, under heavy canopy

[rarity_scale]
- common: baseline
- uncommon: dewglint, duskshadow
