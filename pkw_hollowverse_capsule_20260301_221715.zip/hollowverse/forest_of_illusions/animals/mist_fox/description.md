# mist_fox — description

status: seeded
type: animal_description
parent: mist_fox
region: forest_of_illusions

[description]
A fox with a pale coat that blends easily into fog.
Moves slowly, as if listening more than watching.

[see_also]
- sensory: sensory.md
- behavior: behavior.md
