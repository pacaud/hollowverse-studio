# mist_fox — growth

status: seeded
type: life_cycle
parent: mist_fox
region: forest_of_illusions

[activity_cycle]
- most active: dawn mist + dusk haze
- rests: deep shade during bright daylight
- returns: reliably after fog events (aurora mist, fog blanket)

[seasonal_notes]
- spring/fall: most sightings
- summer: rarer; keeps to water edges and shaded trails
- winter: pawprints sometimes appear even when the fox is not seen
