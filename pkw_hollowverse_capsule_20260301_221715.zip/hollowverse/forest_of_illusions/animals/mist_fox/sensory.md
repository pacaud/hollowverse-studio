# mist_fox — sensory

status: seeded
type: sensory_profile
parent: mist_fox
region: forest_of_illusions

[visual]
- coat: pale, fog-friendly
- silhouette: soft edges; easy to lose in mist

[sound]
- footsteps: near-silent; soft paw placement

[presence]
- feels like being watched gently, not hunted
- often noticed by the *absence* of noise first
