# mist_fox — use

status: seeded
type: use_profile
parent: mist_fox
region: forest_of_illusions

[use]
- discovery scenes
- soft curiosity

[notes]
Use is primarily atmospheric/story anchoring (not a combat creature).
