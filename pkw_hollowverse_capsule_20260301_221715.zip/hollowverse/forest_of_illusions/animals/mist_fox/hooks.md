# mist_fox — hooks

status: seeded
type: story_hooks
parent: mist_fox
region: forest_of_illusions

[scene_hooks]
- A traveler notices pawprints that stop before a dangerous turn.
- The fox appears at the edge of the mist_loop_trail, then vanishes—inviting, not leading.
- Someone follows the *quiet* behind it rather than its shape.
- The fox returns the moment a promise is spoken softly.
- A ribbon left on a branch is found again—placed neatly beside fresh pawprints.
