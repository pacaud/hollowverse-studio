# mist_fox — lore

status: seeded
type: lore_profile
parent: mist_fox
region: forest_of_illusions

[lore]
- Said to guide wanderers without leading them.
