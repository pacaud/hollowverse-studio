# mist_fox — vibe

status: seeded
type: vibe_profile
parent: mist_fox
region: forest_of_illusions

[vibe_keywords]
curious, respectful, quiet
