# mist_fox — behavior

status: seeded
type: behavior_profile
parent: mist_fox
region: forest_of_illusions

[behavior]
- appears near mist_loop_trail
- keeps a gentle distance
- leaves neat paw prints
