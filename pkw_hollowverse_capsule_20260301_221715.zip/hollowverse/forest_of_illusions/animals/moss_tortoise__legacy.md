# moss_tortoise

status: seeded
type: animal
region: forest_of_illusions

[vibe]
slow wisdom, patience

[description]
A large tortoise with moss growing gently on its shell.
It moves very slowly, but always seems to arrive.

[behavior]
- rests in sunpatch_clearing
- barely reacts to noise

[lore]
- A reminder that time is not an enemy.

[use]
- grounding scenes
- patience symbolism
