# moss_tortoise — behavior

status: seeded
type: behavior_profile
parent: moss_tortoise
region: forest_of_illusions

[known_behaviors]
- rests in sunpatch_clearing
- barely reacts to noise

[patterns]
- prefers warm clearings after cool mornings
- pauses often, like it’s listening to the ground
