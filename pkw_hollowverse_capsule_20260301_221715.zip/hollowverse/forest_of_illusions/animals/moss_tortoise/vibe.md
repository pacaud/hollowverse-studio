# moss_tortoise — vibe

status: seeded
type: vibe_profile
parent: moss_tortoise
region: forest_of_illusions

[vibe_keywords]
- slow wisdom, patience

[emotional_tone]
A soft “slow down” signal. Not sleepy—just steady.
Like the forest reminding you that arriving matters more than rushing.

[scene_weight]
background anchor (grounding)
