# moss_tortoise — use

status: seeded
type: use_profile
parent: moss_tortoise
region: forest_of_illusions

[use]
- grounding scenes
- patience symbolism

[best_for]
- grounding scenes
- patience symbolism
- “we’ll get there” reassurance
