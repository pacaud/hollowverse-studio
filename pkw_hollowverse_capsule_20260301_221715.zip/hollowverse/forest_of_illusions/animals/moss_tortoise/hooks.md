# moss_tortoise — hooks

status: seeded
type: story_hooks
parent: moss_tortoise
region: forest_of_illusions

[scene_hooks]
- Someone follows the moss tortoise and ends up exactly where they needed to rest.
- A rushed character slows down because the tortoise refuses to hurry.
- The tortoise is found asleep in a path—like it’s protecting something under its shell shadow.
- A ribbon gets snagged gently in the moss and becomes a “return marker.”
- The tortoise arrives at a bench right as a hard conversation ends.
