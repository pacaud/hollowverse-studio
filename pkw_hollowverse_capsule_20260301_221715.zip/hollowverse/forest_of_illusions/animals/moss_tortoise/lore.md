# moss_tortoise — lore

status: seeded
type: lore_profile
parent: moss_tortoise
region: forest_of_illusions

[lore]
- A reminder that time is not an enemy.

[common_saying]
“If the moss tortoise is nearby, you’re allowed to take your time.”
