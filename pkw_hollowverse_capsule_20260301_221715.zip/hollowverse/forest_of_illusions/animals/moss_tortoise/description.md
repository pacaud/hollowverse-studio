# moss_tortoise — description

status: seeded
type: animal_description
parent: moss_tortoise
region: forest_of_illusions

[description]
A large tortoise with moss growing gently on its shell.
It moves very slowly, but always seems to arrive.

[appearance_notes]
- shell: carries a living moss layer that changes with the season
- eyes: calm, unhurried focus
