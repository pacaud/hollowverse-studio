# moss_tortoise — sensory

status: seeded
type: sensory_profile
parent: moss_tortoise
region: forest_of_illusions

[visual]
- moss-soft shell texture, muted greens and earth browns
- slow movement that feels almost ceremonial

[scent]
- clean damp moss + warm stone

[sound]
- a faint shell-scrape over leaves when it turns
