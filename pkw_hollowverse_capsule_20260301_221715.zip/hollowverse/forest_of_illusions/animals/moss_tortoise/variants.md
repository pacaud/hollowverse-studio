# moss_tortoise — variants

status: seeded
type: variants
parent: moss_tortoise
region: forest_of_illusions

[baseline]
A large tortoise with moss growing gently on its shell.

[known_variants]
- fernback
  - moss grows in fern-like fronds along the rim
- stonecap
  - shell looks more rock-like; moss stays thin and dark
- dewglow
  - morning dew beads and catches light on the moss
