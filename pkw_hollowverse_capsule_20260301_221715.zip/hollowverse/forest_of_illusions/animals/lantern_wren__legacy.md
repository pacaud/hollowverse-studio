# lantern_wren

status: seeded
type: bird
region: forest_of_illusions

[vibe]
gentle presence, light guidance

[description]
A small wren with warm brown feathers and a faintly lighter breast.
Often heard before it’s seen.

[behavior]
- sings softly at dusk and dawn
- hops along cottage paths
- never startles

[lore]
- Considered a friendly signal that the forest is calm.

[use]
- ambient companionship
- return-path scenes
