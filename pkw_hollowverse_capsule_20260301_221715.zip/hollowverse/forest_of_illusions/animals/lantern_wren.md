# lantern_wren

status: seeded
type: bird
region: forest_of_illusions

[quick]
A small wren with warm brown feathers and a faintly lighter breast.

[deep_dive]
- vibe: lantern_wren/vibe.md
- sensory: lantern_wren/sensory.md
- growth: lantern_wren/growth.md
- description: lantern_wren/description.md
- behavior: lantern_wren/behavior.md
- use: lantern_wren/use.md
- lore: lantern_wren/lore.md
- variants: lantern_wren/variants.md
- hooks: lantern_wren/hooks.md
