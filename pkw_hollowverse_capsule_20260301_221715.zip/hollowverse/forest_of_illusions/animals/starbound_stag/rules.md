# starbound_stag — rules

status: legend
type: rules
parent: starbound_stag
region: forest_of_illusions

[rules]
- Never followed.
- Never touched.
- If seen, remain still.
- Let the moment pass without trying to keep it.
