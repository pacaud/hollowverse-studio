# starbound_stag — lore

status: legend
type: lore_profile
parent: starbound_stag
region: forest_of_illusions

[lore]
- Seen at moments of major transition.
- Does not guide, only witnesses.

[common_belief]
The Starbound Stag appears when the forest decides a moment should be remembered—whether or not anyone else is watching.

[whisper]
“Some things don’t need to be chased to be true.”
