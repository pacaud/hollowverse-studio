# starbound_stag — use

status: legend
type: use_profile
parent: starbound_stag
region: forest_of_illusions

[primary_uses]
- turning-point marker (story beats)
- protective atmosphere (a “you are seen” feeling)
- quiet courage scenes

[notes]
It is not an ingredient source.
It is a narrative presence.
