# starbound_stag — behavior

status: legend
type: behavior_profile
parent: starbound_stag
region: forest_of_illusions

[behavior]
- appears briefly
- watches without approaching
- vanishes without sound

[body_language]
- head high, calm
- no threat display
- no invitation either—pure witness

[interaction]
If you move toward it, it won’t “run.”
It will simply no longer be there.
