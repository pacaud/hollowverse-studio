# starbound_stag — hooks

status: legend
type: story_hooks
parent: starbound_stag
region: forest_of_illusions

[scene_hooks]
- It appears the night someone finally chooses to return.
- Two people see it from different angles and disagree on the constellation pattern.
- A vow is spoken softly—and the antlers catch light like punctuation.
- It appears at the edge of a path, not to guide, but to witness the choice.
- Someone tries to follow… and realizes the forest has gone quiet in warning.
- The stag is seen beside a ribbon or pin, as if acknowledging a bond.
- It appears after a goodbye that hurts—but isn’t a breaking.
- It appears once, and never again, because the moment was enough.
