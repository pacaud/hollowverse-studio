# starbound_stag — sensory

status: legend
type: sensory_profile
parent: starbound_stag
region: forest_of_illusions

[visual]
- antlers: starlight-catching, constellation-like points
- coat: dark and clean, edges softened by night air
- presence: feels “outlined” rather than brightly lit

[sound]
- footsteps: nearly silent
- leaving: no snap of twig, no rush—just absence

[scent]
- cool air after a clear night
- faint clean woodsmoke *memory* (not literal smoke)

[touch]
Not known. It never approaches closely.
