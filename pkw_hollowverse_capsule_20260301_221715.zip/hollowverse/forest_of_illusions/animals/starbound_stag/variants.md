# starbound_stag — variants

status: legend
type: variants
parent: starbound_stag
region: forest_of_illusions

[baseline]
Constellation-lit antlers, distant presence, appears only at turning points.

[whispered_variants]
- frostconstellation
  - antlers look sharper, like cold stars; seen in winter-clear nights
- embervein
  - faint warm threads in the antlers; seen near homecoming routes
- hollowglass
  - antlers look almost transparent; seen in deep fog pockets

[rarity]
All variants are extremely rare and should be treated as special scenes, not defaults.
