# starbound_stag — vibe

status: legend
type: vibe_profile
parent: starbound_stag
region: forest_of_illusions

[vibe_keywords]
- awe
- protection
- quiet strength
- “witness, don’t chase”
- turning-point hush

[emotional_tone]
Seeing the Starbound Stag feels like the forest pausing to acknowledge something important—without demanding anything from you.

[tempo]
- onset: instant (you notice the antlers first)
- peak: steady, calm, solemn
- fade: quick (it leaves before the moment becomes a scene)

[limits]
It does not guide. It does not rescue. It simply *witnesses*.
