# starbound_stag — appearance_window

status: legend
type: legend_cycle
parent: starbound_stag
region: forest_of_illusions

[appearance_window]
- turning points only (returns, endings that become beginnings, quiet vows)

[phases]
- distant_glint
  - antlers catch light first, like a small constellation shifting
- witness
  - it stands at the edge of view; still, attentive
- vanish
  - it is simply gone—no retreat sound, no trail

[notes]
Not cultivated. Not tracked. Not summoned.
