# ribbon_deer — hooks

status: seeded
type: story_hooks
parent: ribbon_deer
region: forest_of_illusions

[scene_hooks]
- The ribbon_deer appears at the exact moment someone decides to turn back.
- Two travelers see it from different angles and disagree about where it went.
- A ribbon_deer pauses at a split path as if waiting for someone to catch up.
- A child follows its prints to a safe clearing with a warmstone bench.
- The deer refuses to cross a line—something is wrong beyond it.
- A guide says: “If you see ribbons on its side, you’re being allowed through.”
