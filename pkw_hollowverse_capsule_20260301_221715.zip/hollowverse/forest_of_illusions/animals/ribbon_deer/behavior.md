# ribbon_deer — behavior

status: seeded
type: behavior_profile
parent: ribbon_deer
region: forest_of_illusions

[behavior]
- pauses before crossing paths
- makes eye contact, then leaves
- avoids running unless startled; prefers a quiet, steady walk

[interaction]
If you stay still and soften your posture, it lingers a heartbeat longer—then goes.
