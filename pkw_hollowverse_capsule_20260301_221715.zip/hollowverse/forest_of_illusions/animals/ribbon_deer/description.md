# ribbon_deer — description

status: seeded
type: animal_description
parent: ribbon_deer
region: forest_of_illusions

[description]
A deer with faint ribbon-like markings along its flanks.
It appears briefly at clearing edges, then slips away like a calm thought.

[placement]
Often seen where paths split, where a traveler hesitates, or where the forest feels newly safe.
