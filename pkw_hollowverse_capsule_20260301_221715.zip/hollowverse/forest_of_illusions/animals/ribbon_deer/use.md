# ribbon_deer — use

status: seeded
type: use_profile
parent: ribbon_deer
region: forest_of_illusions

[use]
- transition moments (leaving / returning / choosing a path)
- calm awe scenes
- a “safe route” cue for travelers and guides

[notes]
Not a mount, not a pet—more like a living signpost.
