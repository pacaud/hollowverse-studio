# ribbon_deer — growth

status: seeded
type: animal_cycle
parent: ribbon_deer
region: forest_of_illusions

[cycle]
- most active: dawn, late afternoon, and fog-soft evenings
- avoids: harsh noon light and loud crowded paths

[signs_of_presence]
- shallow hoof prints near clearing edges
- bent grasses where it paused briefly
