# ribbon_deer — lore

status: seeded
type: lore_profile
parent: ribbon_deer
region: forest_of_illusions

[lore]
Seen as a sign of safe movement through the forest.
Old walkers say ribbon_deer appear when the woods agree to let you pass—gently.

[omens]
- one glance, then gone: the route is safe, but keep your pace soft
- lingering at a split: choose with care; both paths are possible
