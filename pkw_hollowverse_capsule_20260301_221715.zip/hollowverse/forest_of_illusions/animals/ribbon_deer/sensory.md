# ribbon_deer — sensory

status: seeded
type: sensory_profile
parent: ribbon_deer
region: forest_of_illusions

[visual]
- faint ribbon-like markings along the flanks (soft, not bright)
- tends to appear at the edge of clearings rather than in the center

[sound]
- light hoof taps on packed soil
- a brief brush-through-leaves sound when it slips away

[notes]
Most sightings are quick—more “glimpse” than “view.”
