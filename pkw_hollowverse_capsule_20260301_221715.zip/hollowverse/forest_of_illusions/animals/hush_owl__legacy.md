# hush_owl

status: rumor
type: bird
region: forest_of_illusions

[vibe]
watchful quiet, deep night

[description]
An owl rarely seen, more often felt.
Its call is said to silence other sounds.

[behavior]
- appears only in deep night
- never seen clearly

[lore]
- Some say it watches over rest.

[notes]
Kept as rumor until observed in canon.
