# night_moth

status: seeded
type: insect
region: forest_of_illusions

[vibe]
quiet wonder, night-soft

[description]
A large moth with velvety wings that catch moonlight softly.

[behavior]
- circles lantern_moss_fern at night
- rests on warm stones

[lore]
- Marks peaceful nighttime.

[use]
- evening ambience
- night scenes
