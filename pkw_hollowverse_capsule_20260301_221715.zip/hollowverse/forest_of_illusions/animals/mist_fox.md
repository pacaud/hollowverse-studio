# mist_fox

status: seeded
type: animal
region: forest_of_illusions

[quick]
A fox with a pale coat that blends easily into fog.

[deep_dive]
- vibe: mist_fox/vibe.md
- sensory: mist_fox/sensory.md
- growth: mist_fox/growth.md
- description: mist_fox/description.md
- behavior: mist_fox/behavior.md
- use: mist_fox/use.md
- lore: mist_fox/lore.md
- variants: mist_fox/variants.md
- hooks: mist_fox/hooks.md
