# burrow_mouse

status: seeded
type: animal
region: forest_of_illusions

[vibe]
small life, everyday comfort

[description]
A tiny forest mouse with bright eyes.
Often seen darting between roots.

[behavior]
- gathers crumbs near stump_table_circle
- freezes, then scurries

[lore]
- A sign that the forest is lived-in.

[use]
- cozy background detail
