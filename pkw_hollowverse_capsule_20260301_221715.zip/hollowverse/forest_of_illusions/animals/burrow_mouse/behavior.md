# burrow_mouse — behavior

status: seeded
type: animal_behavior
parent: burrow_mouse
region: forest_of_illusions

[behavior]
- gathers crumbs near stump_table_circle
- freezes, then scurries

[notes]
They’re brave in pairs, shy alone.
