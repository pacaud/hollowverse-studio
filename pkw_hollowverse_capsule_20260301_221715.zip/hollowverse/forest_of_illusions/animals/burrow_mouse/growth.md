# burrow_mouse — growth

status: seeded
type: animal_growth
parent: burrow_mouse
region: forest_of_illusions

[life_cycle]
- kit (very small, stays close to shelter)
- young (fast, curious, bold for seconds at a time)
- adult (careful route habits, knows the safe roots)

[seasonality]
More visible on clear mornings after damp nights, when crumbs are easy to smell.
