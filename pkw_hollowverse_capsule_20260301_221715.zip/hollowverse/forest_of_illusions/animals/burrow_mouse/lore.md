# burrow_mouse — lore

status: seeded
type: lore_profile
parent: burrow_mouse
region: forest_of_illusions

[lore]
- A sign that the forest is lived-in.

[meaning]
If you see one, it’s usually a soft signal:
the forest is calm enough for small lives to move around.
