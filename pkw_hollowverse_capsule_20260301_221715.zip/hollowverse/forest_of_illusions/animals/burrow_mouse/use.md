# burrow_mouse — use

status: seeded
type: use_profile
parent: burrow_mouse
region: forest_of_illusions

[use]
- cozy background detail

[best_in_scenes]
- warmstone benches
- stump tables
- gentle trails where snacks exist
