# burrow_mouse — description

status: seeded
type: animal_description
parent: burrow_mouse
region: forest_of_illusions

[description]
A tiny forest mouse with bright eyes.
Often seen darting between roots.

[where_you_spot_it]
- between roots and fallen leaves
- near stump tables and low crossings
- anywhere crumbs collect after rest stops
