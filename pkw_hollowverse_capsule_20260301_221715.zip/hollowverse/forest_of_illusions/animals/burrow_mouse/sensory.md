# burrow_mouse — sensory

status: seeded
type: sensory_profile
parent: burrow_mouse
region: forest_of_illusions

[sound]
- tiny leaf-scritch and quick paws
- soft squeak if startled (rare)

[scent]
- faint dry-leaf + warm earth
- sometimes “crumb sweet” near rest spots

[visual]
- bright eyes, quick movements
- tail flicks before it bolts
