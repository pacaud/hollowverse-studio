# burrow_mouse — vibe

status: seeded
type: vibe_profile
parent: burrow_mouse
region: forest_of_illusions

[vibe]
small life, everyday comfort
