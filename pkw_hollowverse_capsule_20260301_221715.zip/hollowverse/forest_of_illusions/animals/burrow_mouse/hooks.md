# burrow_mouse — hooks

status: seeded
type: story_hooks
parent: burrow_mouse
region: forest_of_illusions

[scene_hooks]
- A burrow_mouse leads someone to a hidden crumb stash—right beside a lost item.
- One pauses and stares instead of fleeing, like it recognizes someone.
- A trail feels “too quiet” until a burrow_mouse appears and everything relaxes.
- A tiny path of pawprints crosses a map someone swore was blank.
- Two burrow_mouses argue over a ribbon scrap like it’s treasure.

[linkouts]
- behavior: behavior.md
- lore: lore.md
