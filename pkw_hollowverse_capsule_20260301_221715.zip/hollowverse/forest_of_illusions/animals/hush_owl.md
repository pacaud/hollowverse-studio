# hush_owl

status: rumor
type: bird
region: forest_of_illusions

[quick]
An owl rarely seen, more often felt. Its call is said to silence other sounds.

[deep_dive]
- vibe: hush_owl/vibe.md
- sensory: hush_owl/sensory.md
- growth: hush_owl/growth.md
- description: hush_owl/description.md
- behavior: hush_owl/behavior.md
- lore: hush_owl/lore.md
- use: hush_owl/use.md
- variants: hush_owl/variants.md
- hooks: hush_owl/hooks.md

[notes]
Kept as rumor until observed in canon.
