# lantern_wren — vibe

status: seeded
type: vibe_profile
parent: lantern_wren
region: forest_of_illusions

[vibe_keywords]
- gentle presence
- light guidance
- “safe to keep walking”
- soft companionship

[vibe]
gentle presence, light guidance

[notes]
Lantern wrens are subtle. They don’t lead—you just feel less alone when they’re nearby.
