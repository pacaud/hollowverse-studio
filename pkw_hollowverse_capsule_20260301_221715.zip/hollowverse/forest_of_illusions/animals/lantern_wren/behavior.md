# lantern_wren — behavior

status: seeded
type: behavior_profile
parent: lantern_wren
region: forest_of_illusions

[behavior]
- sings softly at dusk and dawn
- hops along cottage paths
- never startles

[patterns]
- If you stop moving, it sometimes sings again—like it noticed your pause.
- It keeps a respectful distance, but doesn’t flee.
