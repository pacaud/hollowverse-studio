# lantern_wren — use

status: seeded
type: use_profile
parent: lantern_wren
region: forest_of_illusions

[use]
- ambient companionship
- return-path scenes

[notes]
A lantern wren is an atmosphere cue: the forest is calm, and the path is kind.
