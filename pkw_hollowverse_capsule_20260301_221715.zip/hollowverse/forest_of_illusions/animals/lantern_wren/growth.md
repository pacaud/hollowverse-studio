# lantern_wren — growth

status: seeded
type: animal_growth
parent: lantern_wren
region: forest_of_illusions

[life_stages]
- hatchling
  - stays hidden; only tiny peeps
- fledgling
  - clumsy hops; learns the safe edges of paths
- adult
  - dusk/dawn singer; bold enough to be near cottages

[seasonal_notes]
Most active around mild mornings and calm evenings.
