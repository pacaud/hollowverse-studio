# lantern_wren — description

status: seeded
type: animal_description
parent: lantern_wren
region: forest_of_illusions

[description]
A small wren with warm brown feathers and a faintly lighter breast.
Often heard before it’s seen.

[where_you_find_it]
- cottage paths and garden edges
- low branches near rest stones
- quiet clearings where footsteps slow down
