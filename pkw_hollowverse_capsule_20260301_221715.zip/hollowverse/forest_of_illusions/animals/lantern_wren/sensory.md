# lantern_wren — sensory

status: seeded
type: sensory_profile
parent: lantern_wren
region: forest_of_illusions

[sound]
- a soft, bright song at dusk and dawn
- short phrases, then a pause like it’s listening back

[visual]
- warm brown feathers, faintly lighter breast
- quick hops; small silhouette that disappears into leaves

[presence]
- usually heard first
- feels “close” even when it isn’t
