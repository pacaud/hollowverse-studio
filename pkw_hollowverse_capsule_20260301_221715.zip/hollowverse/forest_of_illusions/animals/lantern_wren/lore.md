# lantern_wren — lore

status: seeded
type: lore_profile
parent: lantern_wren
region: forest_of_illusions

[lore]
- Considered a friendly signal that the forest is calm.

[whisper]
Some guides say: “If a lantern wren sings, you don’t need to hurry.”
