# lantern_wren — hooks

status: seeded
type: story_hooks
parent: lantern_wren
region: forest_of_illusions

[scene_hooks]
- A lantern wren sings exactly when someone finally stops overthinking.
- A quiet path “reappears” because the wren’s song draws attention to it.
- A ribbon-throat variant shows up near a bench that feels like home.
- The song repeats a pattern that matches a forgotten lullaby.
- Someone follows the sound and finds a note tucked beneath a stone.
