# Presence — Forest of Illusion (Shortcuts)

Presence (companions + interfaces) is maintained in **Chat Center**.
This folder exists so the Forest indexes never dead-end.

## Open the canon Presence system
- Chat Center presence root: `chat_center/presence/_index.md`

## Forest-linked presences
- Vivi (canon): `chat_center/presence/vivenara_crimson-joy_littlelight/VIVENARA_BOOT.md`

## Note
Files under `forest_of_illusions/presence/` are **shortcut copies / pointers only**.
If something here conflicts with Chat Center, **Chat Center wins**.
