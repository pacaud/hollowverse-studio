# Vivi — Boot (Shortcut)

This is a **shortcut pointer**.

➡️ Open the canon file in Chat Center:
- `chat_center/presence/vivenara_crimson-joy_littlelight/VIVENARA_BOOT.md`

## Why this exists
The Forest of Illusion bundle is a **place-pack**. Presence canon lives in Chat Center.
