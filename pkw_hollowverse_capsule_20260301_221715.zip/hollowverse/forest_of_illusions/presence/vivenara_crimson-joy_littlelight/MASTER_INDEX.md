# Vivi — MASTER_INDEX (Shortcut)

This is a **shortcut pointer**.

➡️ Open the canon file in Chat Center:
- `chat_center/presence/vivenara_crimson-joy_littlelight/MASTER_INDEX.md`
