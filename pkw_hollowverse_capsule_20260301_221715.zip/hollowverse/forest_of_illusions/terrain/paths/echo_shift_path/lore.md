# echo_shift_path — lore

status: seeded
type: lore_profile
parent: echo_shift_path
region: forest_of_illusions

[common_story]
Some walkers say the Echo Shift Path is the forest’s gentle “attention test”:
not to punish you—just to invite you back into the moment.

[meaning]
If it adds a turn, it’s usually asking:
“What did you miss while you were thinking?”
