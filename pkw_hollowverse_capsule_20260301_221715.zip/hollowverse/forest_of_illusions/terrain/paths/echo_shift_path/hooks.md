# echo_shift_path — hooks

status: seeded
type: story_hooks
parent: echo_shift_path
region: forest_of_illusions

[scene_hooks]
- Someone swears the path changed… but their friend insists it didn’t.
- The reroute reveals a tiny marker stone that wasn’t there yesterday.
- A character realizes the extra bend always happens when they’re avoiding a thought.
- Mooncap appears earlier than usual along this trail, hinting the forest is “awake.”
- A calm walker takes the path and it stays perfectly straight.
- The path shifts once—just enough to lead back to a forgotten promise spot.
