# echo_shift_path — description

status: seeded
type: path_description
parent: echo_shift_path
region: forest_of_illusions

[description]
A narrow path that sometimes seems to take one extra turn when you’re distracted.
It’s not dangerous—just… a little strange. Like the forest is asking you to look closer.

[markers]
- echo_birch saplings appear near the edges
- mooncap clusters show up at night
- whisper_frond grows where it narrows
