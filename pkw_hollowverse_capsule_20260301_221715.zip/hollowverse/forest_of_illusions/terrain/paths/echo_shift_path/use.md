# echo_shift_path — use

status: seeded
type: use_profile
parent: echo_shift_path
region: forest_of_illusions

[use]
- discovery scenes
- “the forest is listening” moments

[best_for]
- gentle mystery beats
- noticing small truths without pressure
