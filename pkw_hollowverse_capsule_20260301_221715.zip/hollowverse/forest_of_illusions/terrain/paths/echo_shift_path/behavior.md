# echo_shift_path — behavior

status: seeded
type: path_behavior
parent: echo_shift_path
region: forest_of_illusions

[behavior]
- reliable: medium
- shifts: yes (minor reroutes, never trapping)
- safety: medium-high (stay calm, walk slowly)
