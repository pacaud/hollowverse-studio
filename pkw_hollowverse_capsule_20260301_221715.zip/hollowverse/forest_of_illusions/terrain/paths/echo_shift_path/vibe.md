# echo_shift_path — vibe

status: seeded
type: vibe_profile
parent: echo_shift_path
region: forest_of_illusions

[vibe]
soft mystery, careful curiosity, safe uncertainty
