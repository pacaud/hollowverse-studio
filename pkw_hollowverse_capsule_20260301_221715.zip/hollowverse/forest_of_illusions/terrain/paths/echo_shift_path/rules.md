# echo_shift_path — rules

status: seeded
type: rules
parent: echo_shift_path
region: forest_of_illusions

[rule]
If you feel overwhelmed: stop, breathe, and turn back. The path will allow it.
