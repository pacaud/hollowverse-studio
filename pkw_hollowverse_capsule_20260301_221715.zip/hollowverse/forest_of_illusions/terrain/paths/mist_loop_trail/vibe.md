# mist_loop_trail — vibe

status: seeded
type: vibe_profile
parent: mist_loop_trail
region: forest_of_illusions

[vibe]
quiet wandering, slow reset, fog-soft

[vibe_keywords]
- quiet wandering
- slow reset
- fog-soft
- gentle looping
- “no destination needed”
