# Paths (Forest of Illusions)

**Up:** [Terrain](../_index.md) • [Forest index](../../_index.md)

- [Cottage Return Path](cottage_return_path.md)
- [Mist Loop Trail](mist_loop_trail.md)
- [Echo Shift Path](echo_shift_path.md)
