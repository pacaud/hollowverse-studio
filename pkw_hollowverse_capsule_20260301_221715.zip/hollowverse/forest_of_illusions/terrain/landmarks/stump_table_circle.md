# stump_table_circle

status: seeded
type: landmark
region: forest_of_illusions
updated: 2026-01-23

[vibe]
cozy meeting, small rituals, friendly

[description]
A small circle of old stumps around one wider stump like a table.
Nothing fancy—just a spot the forest keeps clear.

[nearby]
- softbloom_shrub framing the edge
- honey_spore sometimes near the stumps
- ribbonleaf_groundplant in tidy lines

[lore]
- Used for tea, notes, tiny offerings, or just sitting together.
- It’s a “no pressure” gathering place.

[use]
- tea scenes
- planning gently
- companion hangout spot
