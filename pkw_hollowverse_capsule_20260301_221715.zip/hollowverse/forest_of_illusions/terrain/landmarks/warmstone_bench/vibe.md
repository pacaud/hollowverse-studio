# warmstone_bench — vibe

status: seeded
type: vibe_profile
parent: warmstone_bench
region: forest_of_illusions

[vibe]
rest, sunlight, simple comfort

[notes]
A landmark that says: you’re allowed to pause here.
