# warmstone_bench — description

status: seeded
type: landmark_description
parent: warmstone_bench
region: forest_of_illusions

[description]
A long, smooth stone that warms in sunlight.
It’s positioned like a bench beside a quiet bend in the cottage_return_path.

[placement]
Positioned like a bench beside a quiet bend in the cottage_return_path.

[nearby]
- ember_saffron in late afternoon
- sunpatch_clearing not far off
- cottage_stream faintly audible
