# warmstone_bench — sensory

status: seeded
type: sensory_profile
parent: warmstone_bench
region: forest_of_illusions

[touch]
- sun-warmed stone (gentle heat, never harsh)
- smooth surface with tiny “weather-polish” texture

[sound]
- quiet bend in the path
- cottage_stream faintly audible at times

[scent]
- clean warm stone + sunlit air
- after rain: a soft mineral dampness

[light]
- brightest in late afternoon
- feels golden, not white
