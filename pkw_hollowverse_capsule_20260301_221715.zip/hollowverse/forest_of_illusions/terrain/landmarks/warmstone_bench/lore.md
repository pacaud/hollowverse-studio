# warmstone_bench — lore

status: seeded
type: lore_profile
parent: warmstone_bench
region: forest_of_illusions

[lore]
- A place people sit without planning to.
- If you’re carrying too much, it feels like the stone “offers its steadiness.”

[meaning]
A spot that borrows steadiness from stone and gives it back as calm.
