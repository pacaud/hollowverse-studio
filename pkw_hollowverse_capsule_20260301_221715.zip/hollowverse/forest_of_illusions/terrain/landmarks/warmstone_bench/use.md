# warmstone_bench — use

status: seeded
type: use_profile
parent: warmstone_bench
region: forest_of_illusions

[use]
- break scenes
- gentle conversations
- grounding pauses

[scene_modes]
- quiet check-ins
- “we made it back” moments
- sunlight rest after fog travel
