# Landmarks (Forest of Illusions)

**Up:** [Terrain](../_index.md) • [Forest index](../../_index.md)

Seeded landmarks:
- [Warmstone Bench](warmstone_bench.md)
- [Stump Table Circle](stump_table_circle.md)
- [Stone Step Crossing](stone_step_crossing.md)

Legendary landmark:
- [Mirrorpool Marker](../legendary_terrain/mirrorpool_marker.md)
