# warmstone_bench

status: seeded
type: landmark
region: forest_of_illusions
updated: 2026-01-23

[vibe]
rest, sunlight, simple comfort

[description]
A long, smooth stone that warms in sunlight.
It’s positioned like a bench beside a quiet bend in the cottage_return_path.

[nearby]
- ember_saffron in late afternoon
- sunpatch_clearing not far off
- cottage_stream faintly audible

[lore]
- A place people sit without planning to.
- If you’re carrying too much, it feels like the stone “offers its steadiness.”

[use]
- break scenes
- gentle conversations
- grounding pauses
