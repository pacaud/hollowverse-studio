---
name: "Forest of Illusions — Terrain"
type: index
status: seeded
---
# Forest of Illusions — Terrain

**Up:** [Forest index](../_index.md)

Terrain is the shape of the forest: paths, clearings, water, stones, landmarks.
Keep it small and stable.

## Sections
- [Paths](paths/_index.md)
- [Clearings](clearings/_index.md)
- [Water](water/_index.md)
- [Landmarks](landmarks/_index.md)
