# fogquiet_clearing

status: seeded
type: clearing
region: forest_of_illusions
updated: 2026-01-23

[quick]
A clearing that tends to collect fog like a blanket.

[deep_dive]
- vibe: fogquiet_clearing/vibe.md
- sensory: fogquiet_clearing/sensory.md
- growth: fogquiet_clearing/growth.md
- description: fogquiet_clearing/description.md
- behavior: fogquiet_clearing/behavior.md
- use: fogquiet_clearing/use.md
- lore: fogquiet_clearing/lore.md
- variants: fogquiet_clearing/variants.md
- hooks: fogquiet_clearing/hooks.md
