# fogquiet_clearing — vibe

status: seeded
type: vibe_profile
parent: fogquiet_clearing
region: forest_of_illusions

[vibe]
soft hush, slow pacing, fog-held calm
