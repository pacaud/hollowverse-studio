# fogquiet_clearing — growth

status: seeded
type: clearing_cycle
parent: fogquiet_clearing
region: forest_of_illusions

[cycle]
- morning: fog settles first; best “reset” time
- midday: fog thins but the hush remains
- dusk: fog returns in pockets, especially near moss beds
- after rain: the clearing holds mist longer than nearby paths

[notes]
The clearing doesn’t trap. It only blurs—enough to slow the mind, not the way out.
