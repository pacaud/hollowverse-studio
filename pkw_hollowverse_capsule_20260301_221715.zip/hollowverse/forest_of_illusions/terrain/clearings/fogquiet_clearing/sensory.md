# fogquiet_clearing — sensory

status: seeded
type: sensory_profile
parent: fogquiet_clearing
region: forest_of_illusions

[air]
- cool, damp, fog-heavy
- feels muted even in daylight

[smell]
- clean damp moss
- faint mushroom-sweet (often from nearby fogbutton)

[sound]
- softened footsteps
- distant water sometimes carries closer than it should

[light]
- diffused; edges blur gently, never sharply
