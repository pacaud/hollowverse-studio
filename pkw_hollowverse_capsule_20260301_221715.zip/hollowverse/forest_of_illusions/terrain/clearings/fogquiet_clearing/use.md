# fogquiet_clearing — use

status: seeded
type: use_profile
parent: fogquiet_clearing
region: forest_of_illusions

[use]
- reset walks
- quiet scenes where words aren’t required

[best_for]
- slow pacing
- “no words required” moments
- gentle regrouping after a long loop

[notes]
If you’re bringing someone here, lower the lantern a notch.
Let the clearing set the volume.
