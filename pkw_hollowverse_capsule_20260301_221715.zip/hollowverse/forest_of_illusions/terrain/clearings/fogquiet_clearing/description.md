# fogquiet_clearing — description

status: seeded
type: clearing_description
parent: fogquiet_clearing
region: forest_of_illusions

[description]
A clearing that tends to collect fog like a blanket.
Even in daylight, it feels muted and gentle.

[ground]
- mossy patches
- fogbutton mushrooms scattered like dots
- whisper_frond at the edges

[nearby]
- mist_pine saplings
- mistblue_bush in the shaded corners

[see_also]
- sensory: sensory.md
- use: use.md
