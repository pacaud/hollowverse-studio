# fogquiet_clearing — lore

status: seeded
type: lore_profile
parent: fogquiet_clearing
region: forest_of_illusions

[lore]
They say this clearing forms when the forest wants a gentle pause-point—
a place where even daylight agrees to be soft.

[whisper]
“If you can’t decide yet, sit. The fog will hold your thought without squeezing it.”

[notes]
Fogbutton often appears here, like little dots of confirmation.
