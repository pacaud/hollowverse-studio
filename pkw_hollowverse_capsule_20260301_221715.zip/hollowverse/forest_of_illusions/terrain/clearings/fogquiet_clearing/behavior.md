# fogquiet_clearing — behavior

status: seeded
type: behavior_profile
parent: fogquiet_clearing
region: forest_of_illusions

[behavior]
- reliable: mostly
- illusion_level: low-medium (fog shifts perception, never traps)
- safety: high
