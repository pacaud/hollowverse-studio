# Clearings (Forest of Illusions)

**Up:** [Terrain](../_index.md) • [Forest index](../../_index.md)

- [Sunpatch Clearing](sunpatch_clearing.md)
- [Fogquiet Clearing](fogquiet_clearing.md)
- [Nightglow Hollow](nightglow_hollow.md)
