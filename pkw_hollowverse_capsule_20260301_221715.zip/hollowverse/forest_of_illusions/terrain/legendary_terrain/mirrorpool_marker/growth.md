# mirrorpool_marker — growth

status: legend
type: appearance_cycle
parent: mirrorpool_marker
region: forest_of_illusions

[appearance_window]
- turning points only (returns, vows, restorations, “truth moments”)

[stages]
- hint
  - a feeling that the path is turning inward
- reveal
  - the pool (or stone circle) is suddenly “there”
- settle
  - time slows; clarity feels possible
- release
  - it fades when the moment has passed

[notes]
Not cultivated. Not chased. It arrives when it means to.
