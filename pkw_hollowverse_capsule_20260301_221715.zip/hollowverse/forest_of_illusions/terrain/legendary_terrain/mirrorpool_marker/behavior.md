# mirrorpool_marker — behavior

status: legend
type: landmark_behavior
parent: mirrorpool_marker
region: forest_of_illusions

[behavior]
- appears only at meaningful turning points
- never forces revelations
- disappears if approached with urgency or hunger

[interaction_style]
- never forces revelations
- the “answer” can be as small as a breath
- vanishes if approached with urgency or hunger
