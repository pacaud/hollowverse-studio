# mirrorpool_marker — hooks

status: legend
type: story_hooks
parent: mirrorpool_marker
region: forest_of_illusions

[scene_hooks]
- Someone finds the mirrorpool right after admitting a truth out loud.
- Two travelers see different reflections—and both are gentle.
- The pool shows only sky… and that’s the answer.
- A vow is made quietly at the rim, then the landmark fades like a blessing released.
- A character approaches too fast—and it vanishes, teaching “slow down” without punishment.
- The stone circle is empty, but the feeling of water remains.
- A ribbon/pin/keepsake catches the reflection and reveals a small missing detail.
- The forest offers the mirrorpool during a return home that finally “counts.”
