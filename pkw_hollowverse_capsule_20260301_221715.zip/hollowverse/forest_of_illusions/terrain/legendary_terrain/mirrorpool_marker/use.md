# mirrorpool_marker — use

status: legend
type: use_profile
parent: mirrorpool_marker
region: forest_of_illusions

[use]
- restoration milestones
- vow moments
- “I can be honest with myself” scenes

[best_for]
- vow moments
- “I can be honest with myself” scenes
- quiet milestone rests
