# mirrorpool_marker — vibe

status: legend
type: vibe_profile
parent: mirrorpool_marker
region: forest_of_illusions

[vibe]
quiet truth, gentle clarity, sacred calm

[notes]
This is a landmark that calms the scene rather than driving it.
