# mirrorpool_marker — description

status: legend
type: landmark_description
parent: mirrorpool_marker
region: forest_of_illusions

[description]
A small pool that reflects more than the sky—sometimes it reflects *a feeling*.
It is never found the same way twice. Some find water; others find a smooth stone circle
with the *idea* of water in the center.

[where_it_is_found]
- never the same way twice
- often after long walks, hard choices, or quiet returns

[see_also]
- lore: lore.md
- rules: rules.md
