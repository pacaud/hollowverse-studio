# mirrorpool_marker — rules

status: legend
type: rules
parent: mirrorpool_marker
region: forest_of_illusions

[rules]
- Never taken from
- No throwing stones, no bottles, no collecting
- If you see it: sit, breathe, and leave it undisturbed

[keep_it_gentle]
- no collecting, no “proof”
- sit, breathe, leave it undisturbed
