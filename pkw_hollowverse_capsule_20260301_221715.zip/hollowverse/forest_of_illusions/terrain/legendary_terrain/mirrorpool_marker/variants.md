# mirrorpool_marker — variants

status: legend
type: variants
parent: mirrorpool_marker
region: forest_of_illusions

[baseline]
A small still pool or a stone circle that holds the *idea* of water.

[whispered_variants]
- glass-still
  - reflection is unusually sharp; clarity feels immediate
- moonring
  - the stone circle glows faintly at the edge, like soft chalklight
- moss-crowned
  - more moss and tiny ferns around the rim; feels extra “safe to rest”

[rarity]
All variants are rare and should be used as special scenes, not defaults.
