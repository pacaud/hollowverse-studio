# mirrorpool_marker — lore

status: legend
type: lore_profile
parent: mirrorpool_marker
region: forest_of_illusions

[lore]
- The forest’s way of offering clarity without demand.
- Not a test. Not a trap. A soft mirror.

[meaning]
Not a test. Not a trap. A soft mirror.
