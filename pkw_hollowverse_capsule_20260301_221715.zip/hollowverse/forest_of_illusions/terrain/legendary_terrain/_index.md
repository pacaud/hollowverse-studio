# Legendary Terrain (Forest of Illusions)

**Up:** [Terrain](../_index.md) • [Forest index](../../_index.md)

Legendary terrain appears only at turning points. Witness only.

- [Mirrorpool Marker](mirrorpool_marker.md)
