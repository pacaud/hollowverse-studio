# echo_birch — lore

status: seeded
type: lore_profile
parent: echo_birch
region: forest_of_illusions

[lore]
- Often grows near paths that “move” when you’re not looking.
- If you pause under it, the forest feels a little more honest.

[whispered_rule]
If you pause under an Echo Birch and take one slow breath, the next choice you make tends to feel “cleaner.”
Not easier—just clearer.
