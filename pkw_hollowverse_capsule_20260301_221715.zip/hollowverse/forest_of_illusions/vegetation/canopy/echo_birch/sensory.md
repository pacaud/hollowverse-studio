# echo_birch — sensory

status: seeded
type: sensory_profile
parent: echo_birch
region: forest_of_illusions

[signature]
- sound: a soft, page-like rustle even in light wind
- scent: cool bark + faint mineral air
- touch: smooth bark with small, cold ridges

[notes]
Best noticed at night or in cool shade—when the “page-rustle” feels like it has meaning.
