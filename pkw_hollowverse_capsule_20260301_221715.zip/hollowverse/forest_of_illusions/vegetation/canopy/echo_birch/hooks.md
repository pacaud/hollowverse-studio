# echo_birch — hooks

status: seeded
type: story_hooks
parent: echo_birch
region: forest_of_illusions

[scene_hooks]
- A path forks—one side has echo birch “page-rustle,” the other goes oddly silent.
- Someone hears their name in the leaves, but only when they stop walking.
- A lantern held too high makes the shimmer vanish; held low, it returns.
- A traveler finds parchment-gold leaves arranged like a message on the trail.
- The birch grows beside a “moving path” that keeps undoing someone’s progress—until they listen.
- A moon-etched trunk reflects a second sky with a missing star.
- A fox or deer refuses to pass until a promise is spoken under the tree.
- A notebook left at the roots stays dry through the night—like the tree protected it.
