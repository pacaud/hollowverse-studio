# echo_birch — vibe

status: seeded
type: vibe_profile
parent: echo_birch
region: forest_of_illusions

[vibe_keywords]
- whispering, moon-bright, path-shifting

[emotional_tone]
Echo Birch carries a “listen closer” feeling—gentle mystery without threat.
It softens the air and makes nearby paths feel slightly less certain (in a cozy way).

[tempo]
- onset: quick (noticed the moment the leaves start talking)
- peak: steady, background
- fade: slow; lingers like a remembered page
