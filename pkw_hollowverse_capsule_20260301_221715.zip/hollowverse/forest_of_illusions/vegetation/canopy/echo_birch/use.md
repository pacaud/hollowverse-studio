# echo_birch — use

status: seeded
type: use_profile
parent: echo_birch
region: forest_of_illusions

[primary_uses]
- Night path scenes
- “I’m listening” moments
- Gentle mystery without danger

[notes]
Echo Birch is mostly an **atmosphere + choice** tree: it marks moments where someone is listening,
deciding, or letting the forest “speak first.”
