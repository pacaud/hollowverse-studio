# mist_pine — sensory

status: seeded
type: sensory_profile
parent: mist_pine
region: forest_of_illusions

[sound]
Deep hush when wind passes through needles.

[scent]
Resin + clean cold air.

[touch]
Rough bark; needles soft but persistent.
