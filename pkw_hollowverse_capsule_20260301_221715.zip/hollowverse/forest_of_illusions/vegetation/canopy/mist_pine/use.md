# mist_pine — use

status: seeded
type: use_profile
parent: mist_pine
region: forest_of_illusions

[use]
- Calm shelter scenes
- Fog ambience anchor
- “It’s okay to slow down” symbol
