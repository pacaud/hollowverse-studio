# mist_pine — vibe

status: seeded
type: vibe_profile
parent: mist_pine
region: forest_of_illusions

[vibe]
steady, quiet protection, fog-friendly
