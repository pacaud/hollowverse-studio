# mist_pine — lore

status: seeded
type: lore_profile
parent: mist_pine
region: forest_of_illusions

[lore]
- A good tree to rest under when the forest feels too loud.
- Fog gathers around it like a blanket, not a warning.
