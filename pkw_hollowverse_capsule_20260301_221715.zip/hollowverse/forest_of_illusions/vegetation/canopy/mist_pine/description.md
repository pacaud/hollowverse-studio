# mist_pine — description

status: seeded
type: tree_description
parent: mist_pine
region: forest_of_illusions

[description]
A tall pine with dark needles and a trunk that seems to drink fog.
It makes the air feel cleaner and calmer nearby.
