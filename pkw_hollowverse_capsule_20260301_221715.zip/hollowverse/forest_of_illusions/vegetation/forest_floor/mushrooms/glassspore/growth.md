# glassspore — growth

status: rumor
type: mushroom_growth
parent: glassspore
region: forest_of_illusions

[grow_time]
- unknown (rumor only)
- reported windows: 1 night to 3 nights after heavy mist

[growth_stages]
- pin (unconfirmed)
  - tiny “clear beads” in moss
- frostcap (reported)
  - translucent cap like thin frosted glass
- fade (reported)
  - seems to dim and *not be there* when you look back

[notes]
Kept as rumor until observed in canon.
