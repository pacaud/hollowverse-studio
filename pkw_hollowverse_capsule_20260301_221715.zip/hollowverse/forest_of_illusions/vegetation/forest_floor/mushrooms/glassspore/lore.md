# glassspore — lore

status: rumor
type: lore_profile
parent: glassspore
region: forest_of_illusions

[lore]
- Said to appear when the forest wants to be seen clearly.
- People disagree on what it looks like, as if it resists being pinned down.

[disagreement]
People report different shapes, sizes, even colors — like it resists being pinned down.

[canon_note]
Kept as rumor until observed in canon.
