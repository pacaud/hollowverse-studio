# glassspore — hooks

status: rumor
type: story_hooks
parent: glassspore
region: forest_of_illusions

[scene_hooks]
- A character tries to describe glassspore and can’t agree with themselves.
- Someone swears it appeared only when they finally told the truth.
- A trail is lost—then “re-found” because glassspore glints once and disappears.
- Two people see the same patch and describe completely different mushrooms.
- A notebook page gains a faint “frost” pattern after a glassspore sighting.
- A guide says: “Don’t touch it. Just… notice it.”
- The forest feels unusually clear the morning after it appears.

[canon_note]
Keep as rumor until a confirmed sighting is logged.
