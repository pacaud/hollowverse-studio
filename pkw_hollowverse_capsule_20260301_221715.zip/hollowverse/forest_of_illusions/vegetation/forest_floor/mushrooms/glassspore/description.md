# glassspore — description

status: rumor
type: mushroom_description
parent: glassspore
region: forest_of_illusions

[description]
Translucent caps that look like thin frosted glass.
Hard to look at directly—like your eyes slide off it.

[behavior_of_light]
- glints softly at an angle, then refuses the same angle twice
- in fog, edges look clearer; in dry air, it’s harder to focus on

[see_also]
- sensory profile: sensory.md
