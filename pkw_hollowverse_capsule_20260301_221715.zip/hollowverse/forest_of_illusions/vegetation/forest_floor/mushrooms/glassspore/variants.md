# glassspore — variants

status: rumor
type: variants
parent: glassspore
region: forest_of_illusions

[baseline]
Translucent, frosted-glass look — never fully consistent.

[whispered_variants]
- mirrorcap
  - looks reflective, but never shows a clear reflection
- dewshard
  - appears as tiny “glass beads” rather than caps
- palehalo
  - edges seem brighter than the center, like a soft ring

[rarity]
All variants are rare and should remain rumor until witnessed in canon.
