# glassspore — use

status: rumor
type: use_profile
parent: glassspore
region: forest_of_illusions

[primary_uses]
- Rare “is this real?” moments
- Soft reality-shift scenes

[scene_rules]
- do not treat as a farm ingredient
- if it appears, it’s a *moment*, not a resource

[see_also]
- lore: lore.md
