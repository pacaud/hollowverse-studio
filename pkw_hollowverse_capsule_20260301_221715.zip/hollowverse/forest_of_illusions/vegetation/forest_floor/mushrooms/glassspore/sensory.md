# glassspore — sensory

status: rumor
type: sensory_profile
parent: glassspore
region: forest_of_illusions

[visual]
- glints softly, then seems to vanish

[touch]
- not recommended (rumor only)

[scent]
- unclear / disputed (most reports mention “cold air” more than smell)

[sound]
- none reported; witnesses usually go quiet mid-sentence
