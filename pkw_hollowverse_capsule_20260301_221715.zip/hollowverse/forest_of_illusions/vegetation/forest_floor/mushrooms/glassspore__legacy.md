# glassspore

status: rumor
type: mushroom
region: forest_of_illusions

[vibe]
fragile, shimmering, uncertain

[description]
Translucent caps that look like thin frosted glass.
Hard to look at directly—like your eyes slide off it.

[sensory]
visual: glints softly, then seems to vanish
touch: not recommended (rumor only)

[lore]
- Said to appear when the forest wants to be seen clearly.
- People disagree on what it looks like, as if it resists being pinned down.

[use]
- Rare “is this real?” moments
- Soft reality-shift scenes

[notes]
Kept as rumor until observed in canon.
