# inkveil — description

status: seeded
type: mushroom_description
parent: inkveil
region: forest_of_illusions

[appearance]
Thin, dark caps with a faint bluish sheen.
The underside forms layered folds—like the forest stitched shadow into fabric.

[where_you_find_it]
- moss beds near shaded bends
- cool stone edges where dampness lingers
- places that feel “unexplained” in a gentle way

[see_also]
- sensory profile: sensory.md
