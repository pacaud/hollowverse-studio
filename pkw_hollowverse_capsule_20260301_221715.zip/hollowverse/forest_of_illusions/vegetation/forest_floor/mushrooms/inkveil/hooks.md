# inkveil — hooks

status: seeded
type: story_hooks
parent: inkveil
region: forest_of_illusions

[scene_hooks]
- A hidden note is found because inkveil clusters “frame” the stone it’s under.
- Someone realizes they’re rushing when they snap a cap—and stops immediately.
- Inkveil appears along a path that “refuses” to be explained in one visit.
- A guide whispers: “If you see inkveil, you’re allowed to ask twice.”
- A bluelace patch shows up the night before an important revelation.
- Two travelers disagree; inkveil makes them slow down enough to listen.
- A lantern reflection in inkveil’s folds reveals a tiny symbol someone missed.
- Inkveil vanishes from a familiar bend—something changed in the air.
- A quiet creature trail threads between inkveil like it’s following rules.
- A character uses inkveil as a vow: “I won’t force this answer tonight.”
- A stonefold cluster marks the entrance to an old, gentle secret path.
- Someone leaves a ribbon/keepsake beside inkveil, then returns at dawn calmer.
