# inkveil — vibe

status: seeded
type: vibe_profile
parent: inkveil
region: forest_of_illusions

[vibe_keywords]
- mysterious
- soft-shadow
- careful curiosity
- “safe unknown”
- slow discovery

[emotional_tone]
Inkveil is the feeling of turning a page gently—quiet, deliberate,
and a little thrilling without ever becoming scary.

[tempo]
- onset: immediate (noticed by its dark folds and faint sheen)
- peak: steady, background “mystery air”
- fade: slow; lingers as a sense of wonder

[limits]
- not ominous by default
- meant to invite patience, not dread
