# inkveil — sensory

status: seeded
type: sensory_profile
parent: inkveil
region: forest_of_illusions

[visual]
- cap: thin and dark, with a faint bluish sheen
- underside: layered folds, like quiet night fabric
- fog effect: edges look cleaner in mist

[scent]
- deep soil
- cool stone

[touch]
- cap: delicate; handle gently
- stem: light, flexible

[sound]
- none; they “feel” like quiet more than they sound

[notes]
One-line pull: “dark, folded caps that smell like cool earth and stone.”
