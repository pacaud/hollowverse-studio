# honey_spore

status: seeded
type: mushroom
region: forest_of_illusions

[vibe]
friendly, sweet, cottage-adjacent

[description]
Warm beige caps with tiny speckles like pollen.
Often found near the edges of clearings.

[sensory]
scent: faint honey + dry grass
visual: cozy, soft-colored

[lore]
- Said to appear when the cottage is “welcoming you back.”
- Not a medicine—just a comforting detail.

[use]
- Homecoming scenes
- Gentle forest “kindness” cues
