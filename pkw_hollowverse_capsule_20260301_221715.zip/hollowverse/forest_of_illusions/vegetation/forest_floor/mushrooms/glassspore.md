# glassspore

status: rumor
type: mushroom
region: forest_of_illusions

[quick]
A rumored translucent mushroom with frosted-glass caps that never looks the same twice.

[deep_dive]
- vibe: glassspore/vibe.md
- sensory: glassspore/sensory.md
- growth: glassspore/growth.md
- description: glassspore/description.md
- use: glassspore/use.md
- lore: glassspore/lore.md
- variants: glassspore/variants.md
- hooks: glassspore/hooks.md
