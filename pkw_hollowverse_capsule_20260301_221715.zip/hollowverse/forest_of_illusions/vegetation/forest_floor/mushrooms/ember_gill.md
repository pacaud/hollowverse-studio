# ember_gill

status: seeded
type: mushroom
region: forest_of_illusions

[vibe]
warm, hearth-adjacent, steady

[description]
Dark caps with rusty-orange gills underneath.
Looks like a tiny ember tucked into shadow.

[sensory]
scent: rich wood + faint spice
touch: slightly velvety cap

[lore]
- Shows up near old fallen logs and sun-warmed stones.
- Feels like “comfort that doesn’t demand attention.”

[use]
- Cozy forest details
- “Small warmth” symbolism
