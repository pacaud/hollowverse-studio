# starpetal

status: seeded
type: flower
region: forest_of_illusions
bloom_time: late afternoon → early night

[vibe]
welcoming, light, reassuring

[description]
Small pale petals with bright, warm centers.
Clusters appear like scattered stars near the ground.

[sensory]
scent: light, clean, slightly sweet
touch: delicate but resilient

[lore]
- Common near cottage-adjacent clearings.
- Often noticed on return paths.

[use]
- “Welcome home” imagery
- Gentle scene grounding
- Low-stakes beauty

[notes]
Safe, familiar, never overwhelming.
