# mist_lily

status: seeded
type: flower
region: forest_of_illusions
bloom_time: early morning fog

[vibe]
cool, gentle, quiet clarity

[description]
A pale lily-like bloom that looks almost translucent in fog.
It opens widest when the air is damp and still.

[sensory]
scent: clean, watery, faintly green
touch: soft petals, cool to the skin

[lore]
- Often found near hidden clearings where the forest “slows down.”
- A sign that today can be calm.

[use]
- Morning reset scenes
- Fog ambience anchor
- Soft “fresh start” marker
