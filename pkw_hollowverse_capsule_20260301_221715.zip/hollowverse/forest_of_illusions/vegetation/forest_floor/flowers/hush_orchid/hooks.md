# hush_orchid — hooks

status: rumor
type: story_hooks
parent: hush_orchid
region: forest_of_illusions

[scene_hooks]
- Two people arrive ready to argue, then notice a hush_orchid and both stop.
- A guide points: “If you see it, choose fewer words.”
- Someone tries to describe it later—and every retelling changes.
- A hush_orchid appears beside a note that was never delivered.
- The flower blooms at a doorway right before a hard conversation.
- A hush_orchid patch replaces where louder flowers used to grow.
- A character pockets a drawing of it (not the flower) as a vow to de-escalate.
- The orchid fades the moment someone speaks too sharply—like a gentle boundary.

[linkouts]
- lore: lore.md
- use: use.md
- sensory: sensory.md
