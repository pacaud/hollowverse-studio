# hush_orchid — variants

status: rumor
type: variants
parent: hush_orchid
region: forest_of_illusions

[baseline]
Muted lavender orchid with a darker center; hard to describe the same way twice.

[whispered_variants]
- paperlilac
  - looks a touch paler; scent leans more “warm paper”
- duskcenter
  - darker center, shows up closer to twilight
- hushwhite
  - almost white petals; rarely reported

[rarity]
All variants remain rumor-tier until observed in canon.
