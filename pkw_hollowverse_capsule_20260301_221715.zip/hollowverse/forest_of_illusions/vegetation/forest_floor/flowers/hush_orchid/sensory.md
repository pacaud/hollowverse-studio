# hush_orchid — sensory

status: rumor
type: sensory_profile
parent: hush_orchid
region: forest_of_illusions

[sensory]
scent: barely-there, like warm paper
sound: some say the air feels “muted” nearby
