# hush_orchid — vibe

status: rumor
type: vibe_profile
parent: hush_orchid
region: forest_of_illusions

[vibe]
quiet, secret, careful
