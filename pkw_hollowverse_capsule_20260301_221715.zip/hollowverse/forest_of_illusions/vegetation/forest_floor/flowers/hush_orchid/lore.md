# hush_orchid — lore

status: rumor
type: lore_profile
parent: hush_orchid
region: forest_of_illusions

[lore]
- Said to appear when words would do harm.
- The forest’s way of asking for silence.
