# hush_orchid — growth

status: rumor
type: flower_growth
parent: hush_orchid
region: forest_of_illusions
bloom_time: unknown (rare)

[appearance_window]
- unknown (rare)

[growth_stages]
- bud
  - closed, muted lavender
- bloom
  - slender petals, darker center
- hushfade
  - petals soften and the air feels quieter for a beat

[conditions]
- prefers: cool shade, damp air, low foot-traffic
- rumored trigger: moments where speaking would sharpen harm
