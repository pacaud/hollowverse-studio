# hush_orchid — use

status: rumor
type: use_profile
parent: hush_orchid
region: forest_of_illusions

[use]
- “Don’t speak yet” moments
- Soft de-escalation scenes
