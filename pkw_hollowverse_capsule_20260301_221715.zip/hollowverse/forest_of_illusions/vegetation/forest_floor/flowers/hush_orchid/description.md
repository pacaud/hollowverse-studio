# hush_orchid — description

status: rumor
type: flower_description
parent: hush_orchid
region: forest_of_illusions
bloom_time: unknown (rare)

[description]
A slender orchid with muted lavender petals and a darker center.
People describe it differently, as if it refuses to be pinned down.

[notes]
Kept as rumor until observed in canon.
