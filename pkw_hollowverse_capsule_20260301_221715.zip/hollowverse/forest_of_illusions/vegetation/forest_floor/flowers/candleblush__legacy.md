# candleblush

status: rumor
type: flower
region: forest_of_illusions
bloom_time: after emotional storms

[vibe]
warm, tender, aftermath

[description]
Soft peach-pink petals that seem faintly lit from within.
Appears singularly or in very small groups.

[sensory]
scent: warm, floral, comforting
visual: looks brighter in dim light

[lore]
- Said to bloom after difficult moments pass.
- Never appears during conflict—only after.

[use]
- Recovery scenes
- Quiet relief moments
- Gentle closure

[notes]
Kept as rumor until observed in canon.
