# starpetal — use

status: seeded
type: use_profile
parent: starpetal
region: forest_of_illusions

[primary_uses]
- “welcome home” imagery
- gentle scene grounding (calm without heaviness)
- low-stakes beauty for familiar routes

[rituals]
- pocket-star: carry one petal as a reminder to go easy on yourself
- return-mark: plant a small cluster near a bend you want to feel safer

[where_it_works_best]
- late afternoon walks
- quiet path scenes
- cottage-adjacent rest spots

[limits]
- not an ingredient-forward flower
- best used as atmosphere, not power
