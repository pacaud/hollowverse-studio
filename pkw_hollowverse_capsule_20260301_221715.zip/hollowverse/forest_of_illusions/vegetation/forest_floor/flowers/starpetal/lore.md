# starpetal — lore

status: seeded
type: lore_profile
parent: starpetal
region: forest_of_illusions

[lore]
- Common near cottage-adjacent clearings.
- Often noticed on return paths, especially when someone comes back tired.

[old_saying]
“If the ground has stars, you made it to the gentle part.”

[omens]
- clusters on both sides of a trail: the path is safe to take slowly
- a new patch near a doorway: someone is coming home soon (or wants to)
