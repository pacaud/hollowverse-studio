# starpetal — hooks

status: seeded
type: story_hooks
parent: starpetal
region: forest_of_illusions

[scene_hooks]
- A tired traveler realizes they’re near home because the ground “turns to stars.”
- Someone leaves a note at a starpetal patch: not romantic—just reassuring.
- A return path loses its starpetals, and nobody can explain why.
- A child-like spirit tries to count the clusters like constellations.
- Two people disagree, then both notice starpetals and lower their voices.
- A guide says: “If you see starpetal, you can stop performing.”
- A rare nightsoft patch blooms later than it should—marking a delayed homecoming.
- Starpetals appear in a place they’ve never grown before, like the forest is making a new welcome.
