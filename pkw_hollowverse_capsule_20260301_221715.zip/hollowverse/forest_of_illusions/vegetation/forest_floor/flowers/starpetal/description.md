# starpetal — description

status: seeded
type: flower_description
parent: starpetal
region: forest_of_illusions

[appearance]
Small pale petals with bright, warm centers. The bloom sits low—close to the ground—so the clusters look like scattered stars tucked into moss and grass.

[placement]
Most common near cottage-adjacent clearings and the gentle bends of return paths, where the light softens in the late day.

[see_also]
- sensory profile: sensory.md
