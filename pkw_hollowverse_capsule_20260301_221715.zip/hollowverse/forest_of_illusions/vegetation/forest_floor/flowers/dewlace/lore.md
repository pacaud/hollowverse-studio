# dewlace — lore

status: seeded
type: lore_profile
parent: dewlace
region: forest_of_illusions

[lore]
- Some say the forest leaves dewlace along paths it wants kept quiet.
- If you find it at a bend, it usually means: “slow down; you’re almost there.”

[omens]
- dewlace appearing where it never grew before: a reminder to be gentle
- dew drying too fast: the day is going to rush you (if you let it)
