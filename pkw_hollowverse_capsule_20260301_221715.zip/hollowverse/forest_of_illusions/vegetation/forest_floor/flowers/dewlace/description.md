# dewlace — description

status: seeded
type: flower_description
parent: dewlace
region: forest_of_illusions

[at_a_glance]
- size: very small; easy to overlook
- petals: white with edges that read as “lace” when wet
- bloom: best at dawn

[description]
A tiny white flower that hides in plain sight.
At dawn, dew beads along the petal edges and makes a lace-like outline.
If you’re rushing, you’ll miss it completely.

[where_you_find_it]
- path edges where moss stays cool
- quiet clearings with early light
- places the forest wants treated gently
