# dewlace — hooks

status: seeded
type: story_hooks
parent: dewlace
region: forest_of_illusions

[scene_hooks]
- Someone is rushing—and only notices dewlace when they finally stop.
- A dawn meeting place is chosen because dewlace always blooms there.
- A trail guide says: “If you see dewlace, walk like you mean no harm.”
- Dewlace appears near a path that’s been too loud lately.
- A character leaves a tiny note under a dewlace patch, trusting it won’t be trampled.
- The lace-edge outline matches a ribbon pattern someone recognizes.
