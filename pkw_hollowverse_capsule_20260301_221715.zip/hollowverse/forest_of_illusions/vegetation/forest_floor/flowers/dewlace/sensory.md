# dewlace — sensory

status: seeded
type: sensory_profile
parent: dewlace
region: forest_of_illusions

[visual]
- dew beads define the petal edge like stitched lace
- disappears visually once the dew dries

[scent]
- almost none
- a clean hint of morning air

[touch]
- fragile, paper-soft
- petals bruise easily if pressed
