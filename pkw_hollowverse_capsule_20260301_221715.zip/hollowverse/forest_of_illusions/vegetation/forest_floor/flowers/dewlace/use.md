# dewlace — use

status: seeded
type: use_profile
parent: dewlace
region: forest_of_illusions

[primary_uses]
- slow pacing scenes
- “notice the small things” moments
- dawn detail anchors

[rituals]
- one-breath pause: stop beside a dewlace patch and take one steady breath
- gentle-route marker: used to hint “walk lightly here” without signage

[limits]
- not an ingredient-forward plant
- mostly atmosphere + pacing support
