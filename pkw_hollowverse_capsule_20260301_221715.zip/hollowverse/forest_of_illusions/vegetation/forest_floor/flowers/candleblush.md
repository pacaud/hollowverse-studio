# candleblush

status: rumor
type: flower
region: forest_of_illusions
bloom_time: after emotional storms

[quick]
Soft peach‑pink petals that look faintly lit from within—seen in the quiet after a hard moment passes.

[deep_dive]
- vibe: candleblush/vibe.md
- sensory: candleblush/sensory.md
- growth: candleblush/growth.md
- description: candleblush/description.md
- use: candleblush/use.md
- lore: candleblush/lore.md
- variants: candleblush/variants.md
- hooks: candleblush/hooks.md
