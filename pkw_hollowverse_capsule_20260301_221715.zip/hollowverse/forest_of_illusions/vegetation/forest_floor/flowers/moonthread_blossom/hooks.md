# moonthread_blossom — hooks

status: seeded
type: story_hooks
parent: moonthread_blossom
region: forest_of_illusions

[scene_hooks]
- A traveler follows moonthread glints instead of a lantern when the battery dies.
- The return route is "rewoven" overnight—new glint lines appear where someone needs them.
- A knotbloom patch marks the exact spot a promise was made.
- A character realizes they’ve been rushing when they tangle a thread—then stops.
- Mistthread blooms early, warning that the night will be fog-heavy.
- Someone leaves a note tucked under a blossom; it’s found at dawn.
- A fox trail avoids the threads perfectly, like it knows they’re sacred.
- The glints form a shape that looks like a door, but only from one angle.
