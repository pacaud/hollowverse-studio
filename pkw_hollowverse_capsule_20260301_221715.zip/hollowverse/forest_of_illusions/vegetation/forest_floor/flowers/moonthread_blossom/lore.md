# moonthread_blossom — lore

status: seeded
type: lore_profile
parent: moonthread_blossom
region: forest_of_illusions

[lore]
- Appears when the forest wants you to rest without retreating.
- Often near the cottage-return route.

[omens]
- thick glint lines: the path is safe, but asks you to slow down
- tangled threads: too much rushing has passed through lately
