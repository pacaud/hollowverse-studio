# moonthread_blossom — use

status: seeded
type: use_profile
parent: moonthread_blossom
region: forest_of_illusions

[primary_uses]
- night walking scenes
- gentle "come back" cue on return routes
- calm magic ambience (soft, non-flashy)

[rituals]
- slowstep: pause near a patch and take three quiet steps on purpose
- threadmark: guides point to moonthread glints instead of hanging signs

[limits]
- not a strong ingredient flower
- best used as atmosphere + navigation kindness
