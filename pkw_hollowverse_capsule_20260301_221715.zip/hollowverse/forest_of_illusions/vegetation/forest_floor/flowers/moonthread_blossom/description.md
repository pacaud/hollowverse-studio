# moonthread_blossom — description

status: seeded
type: flower_description
parent: moonthread_blossom
region: forest_of_illusions

[description]
Small blossoms connected by fine, thread-like stems that glint under moonlight.
From a distance it looks like someone stitched light into the grass.

[where_you_find_it]
- quiet clearings that stay cool at night
- along calm return routes (especially near cottage paths)
- near moss beds that hold moonlight

[see_also]
- sensory profile: sensory.md
