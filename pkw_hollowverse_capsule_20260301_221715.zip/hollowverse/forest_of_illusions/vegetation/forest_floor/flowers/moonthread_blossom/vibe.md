# moonthread_blossom — vibe

status: seeded
type: vibe_profile
parent: moonthread_blossom
region: forest_of_illusions

[vibe_keywords]
- tender
- dreamy
- slow time
- gentle return
- lantern-low quiet

[emotional_tone]
Moonthread Blossom makes the night feel safe to move through.
Not bright, not loud—just a soft "keep going gently" feeling.
