# moonthread_blossom — sensory

status: seeded
type: sensory_profile
parent: moonthread_blossom
region: forest_of_illusions

[scent]
- faint vanilla-cool
- strongest at first bloom (late dusk)

[visual]
- thread-thin stems glint like stitched light
- glimmers softly, never bright
- most visible under moonlight or misty night air

[touch]
- petals: light and soft
- stems: fine and flexible (easy to disturb)
