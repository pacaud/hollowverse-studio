# hush_orchid

status: rumor
type: flower
region: forest_of_illusions
bloom_time: unknown (rare)

[vibe]
quiet, secret, careful

[description]
A slender orchid with muted lavender petals and a darker center.
People describe it differently, as if it refuses to be pinned down.

[sensory]
scent: barely-there, like warm paper
sound: some say the air feels “muted” nearby

[lore]
- Said to appear when words would do harm.
- The forest’s way of asking for silence.

[use]
- “Don’t speak yet” moments
- Soft de-escalation scenes

[notes]
Kept as rumor until observed in canon.
