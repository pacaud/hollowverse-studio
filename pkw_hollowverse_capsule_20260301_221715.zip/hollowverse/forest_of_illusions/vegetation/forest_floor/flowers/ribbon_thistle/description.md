# ribbon_thistle — description

status: seeded
type: flower_description
parent: ribbon_thistle
region: forest_of_illusions

[description]
A thistle with soft ribbon-like filaments woven through its bloom.
Looks sharp at a glance, but the filaments are surprisingly gentle.

[visual]
- sharp guards around the outside
- soft “ribbon” center that catches light
- reads like a tiny protective lantern without the glow
