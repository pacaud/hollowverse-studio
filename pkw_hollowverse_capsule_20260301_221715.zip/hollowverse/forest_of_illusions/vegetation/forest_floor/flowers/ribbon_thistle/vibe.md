# ribbon_thistle — vibe

status: seeded
type: vibe_profile
parent: ribbon_thistle
region: forest_of_illusions

[vibe_keywords]
- protective
- brave
- quietly stubborn
- kind boundary

[emotional_tone]
Ribbon thistle reads like a boundary that doesn’t need to raise its voice.
Sharp from a distance, gentle where it matters.
