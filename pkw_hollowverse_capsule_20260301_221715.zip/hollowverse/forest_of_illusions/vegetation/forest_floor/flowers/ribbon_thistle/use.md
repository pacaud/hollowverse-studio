# ribbon_thistle — use

status: seeded
type: use_profile
parent: ribbon_thistle
region: forest_of_illusions

[use]
- boundary scenes
- “stand your ground” symbolism
- path-edge visual detail
- gentle reminder: protection can be kind

[notes]
Use it when you want a scene to feel defended, not hostile.
