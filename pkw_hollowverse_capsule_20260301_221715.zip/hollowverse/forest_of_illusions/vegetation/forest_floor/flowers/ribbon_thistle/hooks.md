# ribbon_thistle — hooks

status: seeded
type: story_hooks
parent: ribbon_thistle
region: forest_of_illusions

[scene_hooks]
- Ribbon thistle appears along a path someone keeps walking “too fast.”
- A character stops, noticing the soft center after assuming it was all sharp.
- Someone plants ribbon thistle as a promise: “I’ll protect this boundary.”
- The trail edge blooms with it after a difficult conversation ends calmly.
- A guide says: “If you see ribbon thistle, the forest is holding the line for you.”
- A duskguard patch marks the exact spot a secret is finally spoken.
- Frostfilament shows up near a stone step crossing—something old is waking.
