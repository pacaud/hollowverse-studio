# ribbon_thistle — lore

status: seeded
type: lore_profile
parent: ribbon_thistle
region: forest_of_illusions

[lore]
- Grows at the edge of paths that have been walked too many times.
- A reminder: boundaries can be kind.

[trail_saying]
“If it’s ribbon thistle, the forest is asking you to slow down, not turn back.”
