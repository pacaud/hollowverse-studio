# ribbon_thistle — sensory

status: seeded
type: sensory_profile
parent: ribbon_thistle
region: forest_of_illusions

[scent]
- dry
- sun-warm
- faint spice

[touch]
- outer: prickly guards (don’t grab)
- center: soft filaments (surprisingly gentle)
