# candleblush — use

status: rumor
type: use_profile
parent: candleblush
region: forest_of_illusions

[use]
- recovery scenes
- quiet relief moments
- gentle closure

[story_function]
A candleblush sighting signals: “conflict is over; softness is allowed.”
