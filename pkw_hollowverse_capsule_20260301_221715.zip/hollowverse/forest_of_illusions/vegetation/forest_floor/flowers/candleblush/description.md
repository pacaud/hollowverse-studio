# candleblush — description

status: rumor
type: flower_description
parent: candleblush
region: forest_of_illusions

[description]
Soft peach‑pink petals that seem faintly lit from within.
Usually appears alone or in very small groups—like the forest is placing a gentle punctuation mark.

[where_you_find_it]
- edges of quiet clearings
- along recovery routes
- near rest stones after difficult nights
