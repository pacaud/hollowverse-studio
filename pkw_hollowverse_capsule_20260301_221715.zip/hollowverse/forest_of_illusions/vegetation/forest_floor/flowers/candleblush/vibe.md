# candleblush — vibe

status: rumor
type: vibe_profile
parent: candleblush
region: forest_of_illusions

[vibe]
warm, tender, aftermath

[feel]
Candleblush is the “exhale” after a storm—when the world isn’t fixed yet, but it’s safe to be gentle again.
