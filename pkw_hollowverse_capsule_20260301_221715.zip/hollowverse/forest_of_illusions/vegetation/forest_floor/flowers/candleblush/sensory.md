# candleblush — sensory

status: rumor
type: sensory_profile
parent: candleblush
region: forest_of_illusions

[scent]
warm, floral, comforting

[visual]
soft peach‑pink; looks brighter in dim light
faint inner warmth (never harsh, never spotlight)

[touch]
petals feel soft and slightly cool, like shade-warmed silk

[notes]
If you need a one‑line sensory pull:
“peach‑pink petals, warm comforting scent, brighter in low light.”
