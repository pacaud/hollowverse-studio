# candleblush — lore

status: rumor
type: lore_profile
parent: candleblush
region: forest_of_illusions

[lore]
- Said to bloom after difficult moments pass.
- Never appears during conflict—only after.

[meaning]
It’s not a reward. It’s a reassurance: the forest noticed you made it through.
