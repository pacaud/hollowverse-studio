# candleblush — growth

status: rumor
type: flower_growth
parent: candleblush
region: forest_of_illusions

[appearance_window]
Most likely to appear *after* emotional storms—never during.

[stages]
- hushbud
  - small bud with a warm tint, often unnoticed
- candlebloom
  - full bloom; inner warmth visible in dim light
- softfade
  - petals relax and pale, then vanish back into the floor cover

[notes]
Not cultivated. It’s a timing flower: it arrives when the moment is right.
