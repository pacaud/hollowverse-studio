# candleblush — hooks

status: rumor
type: story_hooks
parent: candleblush
region: forest_of_illusions

[scene_hooks]
- A candleblush appears beside the path where someone finally stopped running.
- Two characters notice it at the same time and both go quiet—relief, not sadness.
- It blooms near a bench after a long, honest conversation.
- Someone returns to a place they argued before and finds candleblush waiting.
- A guide says: “If you see candleblush, the night is done hurting you.”
- A cluster blooms (rare) — the forest is closing a chapter gently, but firmly.

[linkouts]
- vibe: vibe.md
- sensory: sensory.md
- lore: lore.md
- use: use.md
