# candleblush — variants

status: rumor
type: variants
parent: candleblush
region: forest_of_illusions

[baseline]
Peach‑pink petals with faint inner warmth; rare; usually solitary.

[whispered_variants]
- duskblush
  - slightly deeper pink; most visible at twilight
- hearthblush
  - warmer inner glow; tends to appear near rest stones
- dewblush
  - petals hold dew longer; found near stream bends after rain

[rarity_scale]
- uncommon: baseline (still rare overall)
- rare: duskblush, dewblush
- very rare: hearthblush
