# mist_lily — lore

status: seeded
type: lore_profile
parent: mist_lily
region: forest_of_illusions

[lore]
- Often found near hidden clearings where the forest “slows down.”
- A sign that today can be calm.
