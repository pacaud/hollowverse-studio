# mist_lily — hooks

status: seeded
type: story_hooks
parent: mist_lily
region: forest_of_illusions

[scene_hooks]
- Someone finds mist_lily at the exact moment they decide to start over gently.
- A clearing full of mist_lily only appears when you stop rushing.
- A ribbon gets caught on a stem; when untied, an old promise feels lighter.
- The flowers close as a lie is told, then open again after an apology.
- A guide uses mist_lily as a “morning reset” ritual for tired travelers.
- A fox path threads between blooms like it’s honoring them.
- The lily opens wider than usual—fog is coming early.
- Two people see the same bloom and realize they arrived together in spirit.
