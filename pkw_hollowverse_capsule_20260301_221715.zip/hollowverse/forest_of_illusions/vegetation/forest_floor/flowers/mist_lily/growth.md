# mist_lily — growth

status: seeded
type: plant_growth
parent: mist_lily
region: forest_of_illusions

[grow_time]
- sprout → bloom: 12–18 days (in cool damp shade)

[growth_stages]
- fogsprout (days 1–4)
- leafset (days 5–9)
- bud (days 10–12)
- bloom (days 13–18; widest in early morning fog)

[notes]
Mist Lily favors still air and damp ground. In dry weeks it stays closed.
