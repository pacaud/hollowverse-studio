# mist_lily — description

status: seeded
type: flower_description
parent: mist_lily
region: forest_of_illusions

[description]
A pale lily-like bloom that looks almost translucent in fog.
It opens widest when the air is damp and still.
