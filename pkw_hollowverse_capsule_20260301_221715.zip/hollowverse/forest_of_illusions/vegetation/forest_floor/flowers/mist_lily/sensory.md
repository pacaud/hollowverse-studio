# mist_lily — sensory

status: seeded
type: sensory_profile
parent: mist_lily
region: forest_of_illusions

[sensory]
scent: clean, watery, faintly green
touch: soft petals, cool to the skin
