# mist_lily — vibe

status: seeded
type: vibe_profile
parent: mist_lily
region: forest_of_illusions

[vibe]
cool, gentle, quiet clarity
