# mist_lily — use

status: seeded
type: use_profile
parent: mist_lily
region: forest_of_illusions

[use]
- Morning reset scenes
- Fog ambience anchor
- Soft “fresh start” marker
