# hush_orchid

status: rumor
type: flower
region: forest_of_illusions
bloom_time: unknown (rare)

[quick]
A slender orchid with muted lavender petals—rumored to appear when silence is kinder than words.

[deep_dive]
- vibe: hush_orchid/vibe.md
- sensory: hush_orchid/sensory.md
- growth: hush_orchid/growth.md
- description: hush_orchid/description.md
- use: hush_orchid/use.md
- lore: hush_orchid/lore.md
- variants: hush_orchid/variants.md
- hooks: hush_orchid/hooks.md
