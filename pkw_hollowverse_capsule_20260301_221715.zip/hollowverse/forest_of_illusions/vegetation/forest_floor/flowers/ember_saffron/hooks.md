# ember_saffron — hooks

status: seeded
type: story_hooks
parent: ember_saffron
region: forest_of_illusions

[scene_hooks]
- A single ember saffron blooms near a path someone avoided for weeks.
- A character realizes it’s late afternoon only when ember saffron opens.
- A bench feels warmer because a patch gathers beside it.
- Someone leaves a note under a fallen log marked by ember saffron.
- A rare hearthgold bloom appears on the day a promise is kept.
- The flowers don’t bloom today—someone is rushing and doesn’t notice why.
- A fox pauses near the blossoms like it’s listening to the light.
- A pressed petal in a journal becomes a “return later” promise.
