# ember_saffron — sensory

status: seeded
type: sensory_profile
parent: ember_saffron
region: forest_of_illusions

[scent]
- warm honey + dry leaves
- strongest right as the sun lowers

[visual]
- sunset light: appears to glow (orange-gold, emberlike)
- shade: matte and calm, almost velvety

[touch]
- petals: soft, lightly thickened at the rim
- stem: thin, flexible, not brittle

[sound]
- none; it’s a “quiet warmth” kind of flower
