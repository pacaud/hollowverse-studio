# ember_saffron — use

status: seeded
type: use_profile
parent: ember_saffron
region: forest_of_illusions

[use]
- Comfort scenes
- “Small warmth” symbolism
- Late-day light anchor

[rituals]
- lantern-pause: stop beside a bloom and take one slow breath before heading home
- pocket-promise: press a fallen petal into a page as a reminder to return

[limits]
Mostly atmosphere + meaning (not an ingredient-forward plant).
