# ember_saffron — lore

status: seeded
type: lore_profile
parent: ember_saffron
region: forest_of_illusions

[lore]
- Often grows near fallen logs and sunlit stones.
- A sign that warmth can be simple.

[common_saying]
“If you can spot ember saffron, you’ve still got time for one gentle thing.”
