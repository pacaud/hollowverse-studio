# ember_saffron — description

status: seeded
type: flower_description
parent: ember_saffron
region: forest_of_illusions

[description]
A small cup-shaped bloom with warm orange-gold tones.
It looks like a tiny ember caught in petals.

[sensory_snapshot]
- scent: warm honey + dry leaves
- visual: glows in sunset light, matte in shade

[placement]
Often grows near fallen logs and sunlit stones, especially where late-day light lingers.

[see_also]
- sensory profile: sensory.md
