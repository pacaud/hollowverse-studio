# dewlace

status: seeded
type: flower
region: forest_of_illusions
bloom_time: dawn

[vibe]
soft, delicate, attentive

[description]
A tiny white flower with petal edges that look like lace when wet with dew.
It’s easy to miss unless you’re moving slowly.

[sensory]
scent: almost none; a clean hint of air
touch: fragile, paper-soft

[lore]
- The forest “leaves these” along paths it wants kept quiet.
- A marker for careful steps and gentle pacing.

[use]
- Slow pacing scenes
- “Notice the small things” moments
- Dawn detail
