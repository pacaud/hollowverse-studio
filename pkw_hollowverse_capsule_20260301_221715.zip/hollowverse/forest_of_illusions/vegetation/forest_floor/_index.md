# Forest Floor

**Up:** [Vegetation index](../_index.md)

## Sections
- [Flowers](flowers/_index.md)
- [Herbs](herbs/_index.md)
- [Mushrooms](mushrooms/_index.md)
