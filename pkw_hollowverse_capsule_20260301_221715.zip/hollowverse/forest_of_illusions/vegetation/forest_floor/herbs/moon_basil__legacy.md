# moon_basil

status: seeded
type: herb
region: forest_of_illusions

[vibe]
night-calm, dream-soft, gentle

[description]
Dark green leaves with a subtle sheen.
Opens more fully at night.

[sensory]
scent: sweet-herbal, soothing
touch: cool and smooth

[lore]
- Associated with restful nights.
- Sometimes found near moonthread_blossom.

[use]
- Night scenes
- Sleep-adjacent comfort
