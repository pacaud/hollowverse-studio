# brightmint

status: seeded
type: herb
region: forest_of_illusions

[vibe]
fresh, alert, clean reset

[description]
Small bright leaves with crisp edges.
Looks lively even in shade.

[sensory]
scent: cool, sharp, refreshing
taste: clean, invigorating

[lore]
- Grows where new paths begin.
- Signals fresh starts without pressure.

[use]
- Reset moments
- Morning scenes
