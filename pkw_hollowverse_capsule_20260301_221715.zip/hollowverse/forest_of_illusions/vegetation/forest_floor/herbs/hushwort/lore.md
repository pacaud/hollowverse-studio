# hushwort — lore

status: rumor
type: lore_profile
parent: hushwort
region: forest_of_illusions

[lore]
- Said to quiet spiraling thoughts.
- Appears only when silence is kinder than action.

[common_saying]
“When hushwort appears, the forest is asking for kindness before action.”
