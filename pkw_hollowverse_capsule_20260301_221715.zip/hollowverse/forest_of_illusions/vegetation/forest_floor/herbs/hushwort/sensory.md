# hushwort — sensory

status: rumor
type: sensory_profile
parent: hushwort
region: forest_of_illusions

[scent]
- barely noticeable

[air]
- air feels muted nearby

[visual]
- slender muted leaves
- easily overlooked; blends into surrounding greens

[touch]
- light and dry (not brittle)
