# hushwort — vibe

status: rumor
type: vibe_profile
parent: hushwort
region: forest_of_illusions

[vibe]
quiet, careful, inward

[core_feel]
Hushwort is the feeling of choosing “pause” instead of “push.”
It doesn’t fix things—just lowers the volume enough to breathe.
