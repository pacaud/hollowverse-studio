# hushwort — use

status: rumor
type: use_profile
parent: hushwort
region: forest_of_illusions

[use]
- De-escalation scenes
- “Not yet” moments

[scene_roles]
- de-escalation anchor (“let’s slow down”)
- boundary cue (“not yet” / “later”)
- quiet support near rest spots
