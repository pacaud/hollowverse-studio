# hushwort — hooks

status: rumor
type: story_hooks
parent: hushwort
region: forest_of_illusions

[scene_hooks]
- A tense conversation softens the moment someone notices hushwort at their feet.
- A guide refuses to walk faster once hushwort appears: “Not tonight.”
- Hushwort grows only on one side of a forked path—the quieter choice.
- A rest stone that’s always chaotic becomes calm when hushwort returns.
- Someone tries to pick it, and realizes it’s not for taking—only for noticing.
- Hushwort vanishes the day after a vow is broken.
- A “not yet” decision becomes a “now” decision the day hushwort flowers (rare).
- Two people find the same patch separately and both feel seen.
