# hushwort — description

status: rumor
type: herb_description
parent: hushwort
region: forest_of_illusions

[description]
Slender muted leaves, easily overlooked.
Seems to blend into its surroundings.

[where_you_find_it]
- shaded trail edges
- behind stones, under low shrubs
- places that feel “too loud” until you step closer

[notes]
Kept as rumor until observed in canon.
