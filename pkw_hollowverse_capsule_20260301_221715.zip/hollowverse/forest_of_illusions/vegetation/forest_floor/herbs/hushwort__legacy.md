# hushwort

status: rumor
type: herb
region: forest_of_illusions

[vibe]
quiet, careful, inward

[description]
Slender muted leaves, easily overlooked.
Seems to blend into its surroundings.

[sensory]
scent: barely noticeable
effect: air feels muted nearby

[lore]
- Said to quiet spiraling thoughts.
- Appears only when silence is kinder than action.

[use]
- De-escalation scenes
- “Not yet” moments

[notes]
Kept as rumor until observed in canon.
