# hushwort

status: rumor
type: herb
region: forest_of_illusions

[quick]
A muted herb that reads like “soft quiet”—kept as rumor until observed in canon.

[deep_dive]
- vibe: hushwort/vibe.md
- sensory: hushwort/sensory.md
- growth: hushwort/growth.md
- description: hushwort/description.md
- use: hushwort/use.md
- lore: hushwort/lore.md
- variants: hushwort/variants.md
- hooks: hushwort/hooks.md
