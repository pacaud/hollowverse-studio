# calmleaf

status: seeded
type: herb
region: forest_of_illusions

[vibe]
settling, gentle, grounding

[description]
Soft matte green leaves with rounded edges.
Often found near quiet paths and resting places.

[sensory]
scent: mild, grassy, comforting
touch: soft and pliable

[lore]
- Used in tea-adjacent comfort lore.
- The forest’s way of saying “slow down.”

[use]
- Grounding scenes
- Emotional easing
