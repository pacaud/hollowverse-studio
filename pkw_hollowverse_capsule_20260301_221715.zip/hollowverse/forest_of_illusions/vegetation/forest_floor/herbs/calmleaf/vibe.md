# calmleaf — vibe

status: seeded
type: vibe_profile
parent: calmleaf
region: forest_of_illusions

[vibe_keywords]
- settling
- gentle grounding
- soft quiet
- “you can slow down”

[emotional_tone]
Calmleaf doesn’t sharpen the world. It softens the edges.
The vibe is simple: slow breath, steady hands, a calmer pace.
