# calmleaf — sensory

status: seeded
type: sensory_profile
parent: calmleaf
region: forest_of_illusions

[scent]
- mild, grassy, comforting
- strongest when warmed between fingers

[touch]
- soft and pliable leaves
- matte surface; never glossy

[visual]
- rounded edges
- muted green, like shade-light

[notes]
One-line sensory: “soft matte green leaves, grassy-comfort scent.”
