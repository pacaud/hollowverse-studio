# calmleaf — use

status: seeded
type: use_profile
parent: calmleaf
region: forest_of_illusions

[primary_uses]
- grounding scenes
- emotional easing (soft, not forceful)
- rest-spot companion herb (benches, nooks, warm stones)

[rituals]
- finger-warm: warm a leaf between fingers before speaking
- page-marker: press a leaf to mark a stopping point (journals, maps)

[where_it_works_best]
- cool shade
- quiet paths
- places that encourage slow breath

[limits]
- not a stimulant
- support, not override
