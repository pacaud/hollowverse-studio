# calmleaf — lore

status: seeded
type: lore_profile
parent: calmleaf
region: forest_of_illusions

[common_belief]
Calmleaf is the forest’s gentle way of saying: “slow down.”

[tea-adjacent_lore]
It shows up in comfort stories—warm cups, quiet nooks, soft talks.
Not because it fixes anything, but because it makes room to breathe.

[trail_lore]
Old walkers say if you find calmleaf near a stone or bench,
the place is safe enough to rest for a minute.
