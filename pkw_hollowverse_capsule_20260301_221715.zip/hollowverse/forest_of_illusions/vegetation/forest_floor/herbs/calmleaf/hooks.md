# calmleaf — hooks

status: seeded
type: story_hooks
parent: calmleaf
region: forest_of_illusions

[scene_hooks]
- A calmleaf patch appears beside a bench that wasn’t there yesterday.
- Someone can’t talk yet—so they warm a leaf between fingers first.
- A map has a pressed calmleaf leaf on the one spot marked “rest.”
- Calmleaf won’t grow in one usually-safe place anymore. Why?
- Two travelers argue, then notice calmleaf underfoot—and both lower their voice.
- A guide says: “If you see calmleaf, you’re allowed to stop walking.”
- A forgotten note is found because someone used calmleaf as a page marker.
- A warmstone calmleaf variant shows up, hinting the path is safe even after sunset.
