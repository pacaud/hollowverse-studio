# golden_gingerroot

status: seeded
type: herb
region: forest_of_illusions

[vibe]
warm, steady, hearth-adjacent

[description]
Low plant with sturdy stems and warm-toned root.
Often near sun-warmed stones.

[sensory]
scent: warm spice, earth
taste: gentle heat

[lore]
- A symbol of quiet strength.
- Used when energy needs steadiness, not speed.

[use]
- Comfort scenes
- Slow energy support
