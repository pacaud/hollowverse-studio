# honey_thyme — vibe

status: seeded
type: vibe_profile
parent: honey_thyme
region: forest_of_illusions

[vibe_keywords]
- comforting
- kind
- supportive
- gentle warmth
- “you’re allowed to rest”

[emotional_tone]
Honey thyme feels like care that doesn’t ask to be noticed.
It’s the quiet helper herb—present, steady, never dominant.

[tempo]
- onset: subtle (noticed more in hindsight than in the moment)
- peak: soft and steady
- fade: slow; leaves a “held” feeling

[compatibility]
- pairs well with: warm stone rests, softsage, low lantern light
- works best near: recovery nooks, safe trails, cottage edges

[limits]
- not energizing
- not dramatic magic—more comfort than “effect”
