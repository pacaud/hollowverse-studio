# honey_thyme — lore

status: seeded
type: lore_profile
parent: honey_thyme
region: forest_of_illusions

[common_belief]
Honey thyme represents care given without asking.
It’s the forest’s “extra touch”—the small kindness nobody demanded.

[trail_lore]
Some walkers tuck a sprig near a rest stone to say:
“Someone was here, and they wanted you safe.”

[quiet_customs]
- Leaving a tiny bundle for the next traveler (no name attached)
- Planting it near benches where hard conversations happen softly
- Pairing it with softsage when choices feel heavy

[omens]
- honey thyme appearing in a new spot: someone is being looked after
- gold tips fading early: the place has become too dry or too rushed

[see_also]
- use: use.md
- hooks: hooks.md
