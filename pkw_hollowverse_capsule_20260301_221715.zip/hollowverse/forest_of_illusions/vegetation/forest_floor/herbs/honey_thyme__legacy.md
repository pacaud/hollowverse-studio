# honey_thyme

status: seeded
type: herb
region: forest_of_illusions

[vibe]
comforting, kind, supportive

[description]
Tiny clustered leaves with faint golden tips.
Often mixed among other plants, never dominant.

[sensory]
scent: warm herbal sweetness
taste: mild, soothing

[lore]
- Represents care given without asking.
- The forest’s “extra touch.”

[use]
- Care scenes
- Recovery moments
