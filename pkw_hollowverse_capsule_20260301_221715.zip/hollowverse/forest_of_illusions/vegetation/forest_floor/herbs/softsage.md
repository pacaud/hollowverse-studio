status: seeded
type: herb
region: forest_of_illusions

[quick]
A low, velvety herb found near cool clearings and quiet paths.

[deep_dive]
- vibe: softsage/vibe.md
- sensory: softsage/sensory.md
- growth: softsage/growth.md
- description: softsage/description.md
- use: softsage/use.md
- lore: softsage/lore.md
- variants: softsage/variants.md
- hooks: softsage/hooks.md