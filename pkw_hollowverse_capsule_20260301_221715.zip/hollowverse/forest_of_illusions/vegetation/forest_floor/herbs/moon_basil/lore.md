# moon_basil — lore

status: seeded
type: lore_profile
parent: moon_basil
region: forest_of_illusions

[lore]
- Associated with restful nights and kinder dreams.
- Sometimes found near moonthread_blossom, as if the two plants keep each other company.

[old_trail_saying]
“If the basil opens, the forest is ready to sleep.”

[omens]
- a fresh patch near a threshold: the day is ending cleanly
- leaves staying closed at dusk: the air is too dry (or the place is unsettled)
