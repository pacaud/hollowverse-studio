# moon_basil — use

status: seeded
type: use_profile
parent: moon_basil
region: forest_of_illusions

[primary_uses]
- night scenes and evening ambience
- sleep-adjacent comfort (without “forcing” sleep)
- gentle grounding for dreamstate moments

[rituals]
- dusk crush: rub a leaf lightly between fingers and breathe once, slow
- lantern pause: place a small sprig near a lantern before resting
- page-press: press a leaf into a notebook as a “close the day” marker

[limits]
- not a strong stimulant or sedative
- meant as atmosphere and support, not override
