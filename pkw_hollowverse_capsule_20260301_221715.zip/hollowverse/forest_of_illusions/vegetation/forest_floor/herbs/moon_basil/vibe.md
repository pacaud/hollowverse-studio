# moon_basil — vibe

status: seeded
type: vibe_profile
parent: moon_basil
region: forest_of_illusions

[vibe_keywords]
- night-calm
- dream-soft
- gentle
- “lantern low”
- quiet comfort

[emotional_tone]
Moon basil feels like the moment right before sleep,
when the world finally stops asking anything of you.

[tempo]
- onset: subtle (noticed most at dusk)
- peak: steady, background calm
- fade: slow, leaving a soft “settled” after-feel

[compatibility]
- pairs well with: aurora mist, moonlight clearings, warmstone rests
- works best near: shaded paths and sleep-adjacent nooks
