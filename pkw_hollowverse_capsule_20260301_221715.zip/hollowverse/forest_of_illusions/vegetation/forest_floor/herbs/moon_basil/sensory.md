# moon_basil — sensory

status: seeded
type: sensory_profile
parent: moon_basil
region: forest_of_illusions

[scent]
- sweet-herbal, soothing
- strongest at night when leaves open fully

[touch]
- cool and smooth
- leaves feel slightly firmer than softsage, but still gentle

[visual]
- dark green leaves with a subtle sheen
- edges look clearer in moonlight

[notes]
If you need a one-line sensory pull:
“sweet-herbal night basil, cool to the touch, with a soft moon sheen.”
