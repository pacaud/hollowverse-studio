# moon_basil — hooks

status: seeded
type: story_hooks
parent: moon_basil
region: forest_of_illusions

[scene_hooks]
- A character can’t sleep until they find moon basil and do the dusk-crush ritual.
- Moon basil opens early—something in the night is unusually gentle.
- A patch appears beside a notebook that’s been left blank for too long.
- Someone follows the faint sheen of leaves to a hidden rest nook.
- Moon basil refuses to open at dusk, warning the area has turned too dry or tense.
- A dream message is left as a pressed leaf inside a book, found at morning light.
- Two paths diverge; moon basil grows only along the quieter one.
- A fox trail circles a moon basil patch like it’s guarding the calm.
