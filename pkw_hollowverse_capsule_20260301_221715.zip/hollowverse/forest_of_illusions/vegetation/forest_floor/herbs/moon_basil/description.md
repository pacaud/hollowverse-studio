# moon_basil — description

status: seeded
type: herb_description
parent: moon_basil
region: forest_of_illusions

[appearance]
Dark green leaves with a subtle sheen, like they’re holding a small piece of night.
At dusk the plant seems to relax—leaves opening a little wider, posture softening.

[where_you_find_it]
- cool edges of clearings
- along shaded paths that stay calm at night
- sometimes near moonthread_blossom patches

[see_also]
- sensory profile: sensory.md
