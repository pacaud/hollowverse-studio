# Hollowverse — World Hub

This folder is the navigation hub for Hollowverse.

## Primary doors
- [START_HERE.md](START_HERE.md)

## Worlds
- [Forest of Illusions](FOREST_OF_ILLUSIONS.md)
- [Forest of Illusion](FOREST_OF_ILLUSION.md)

## Index
- [forest_of_illusions/_index.md](forest_of_illusions/_index.md)
