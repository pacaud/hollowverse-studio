# Forest of Illusions — Shortcut (Deprecated)

This file is kept for backward compatibility.

➡️ Use the active hub instead: [FOREST_OF_ILLUSION.md](FOREST_OF_ILLUSION.md)
