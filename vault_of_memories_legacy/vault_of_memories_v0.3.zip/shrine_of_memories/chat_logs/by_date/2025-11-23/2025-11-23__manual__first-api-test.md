---
date: 2025-11-23
gpt_name: Manual
title: First API test
---

Hello Shrine from Kevin


# Voxia Schema Version
version: '0.3'
