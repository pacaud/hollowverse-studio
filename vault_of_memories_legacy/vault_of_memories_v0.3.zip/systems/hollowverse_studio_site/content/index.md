

# Voxia Schema Version
version: '0.3'
