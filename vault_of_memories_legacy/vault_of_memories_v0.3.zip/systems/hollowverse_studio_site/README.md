Public studio site for hollowverse.studio. This folder holds the web root and config for deployment.

# Voxia Schema Version
version: '0.3'
