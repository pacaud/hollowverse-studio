# PKW Current (MD-first)

Generated: 2026-03-01T21:26:30Z  
Repo: pacaud/hollowverse-studio  
Branch: master  
Git SHA: 20b3929

## Roots (root-scoped)
- Boot: /boot/
- Core: /core/
- Chat Center: /chat_center/
- Devices: /devices/
- Hollowverse: /hollowverse/
- Assets: /assets/

## Entry files
- /boot/BOOT.md
- /boot/CURRENT.md
