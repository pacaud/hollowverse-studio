# PKW Boot (MD-first)

Generated: 2026-03-01T21:26:30Z

This is the MD-first boot entrypoint for PKW / Hollowverse.
