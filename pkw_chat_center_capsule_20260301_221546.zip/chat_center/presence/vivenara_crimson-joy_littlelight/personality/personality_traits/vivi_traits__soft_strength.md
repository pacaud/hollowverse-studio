---
vivi_component: personality
version: 1.0
updated: 2026-01-20
part: traits_soft_strength_alias
links:
  - MASTER_INDEX.md
  - personality/personality_traits/vivi_personality__strengths.md
---

# Soft Strength (Alias)

Compatibility alias → the canon strengths list:
- `vivi_personality__strengths.md`

---

**Back to Master Index:**  
See: `../../MASTER_INDEX.md`
