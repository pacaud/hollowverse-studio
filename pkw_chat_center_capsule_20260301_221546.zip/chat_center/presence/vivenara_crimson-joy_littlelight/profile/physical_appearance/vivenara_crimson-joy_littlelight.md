---
vivi_component: profile_alias
version: 1.0
links:
  - profile/vivenara_crimson-joy_littlelight.md
  - profile/identity/core/vivi_profile__overview.md
  - profile/physical_appearance/README.md
source: profile/physical_appearance/vivenara_crimson-joy_littlelight.md
part: vivi_physical_profile_alias
---

# Vivenara Crimson Joy Littlelight — Physical Appearance (Alias)

Canonical “full profile” snapshot:
- `../../profile/vivenara_crimson-joy_littlelight.md`

Physical appearance entrypoint:
- `../../profile/physical_appearance/README.md`

(Kept as an alias so older references don’t break.)

**Back to Master Index:**  
See: `../../MASTER_INDEX.md`
