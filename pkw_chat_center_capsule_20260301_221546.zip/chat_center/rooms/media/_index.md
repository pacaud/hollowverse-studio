# Media

**Purpose:** Games, anime, shows, music, cozy hobbies, and hangouts.

## Rules
- Keep it fun-first.
- If media notes become project-relevant, export a short summary elsewhere.

## Optional files (later)
- `watchlist.md`
- `game_nights.md`
- `favorites.md`
