## Accessories
- **Five Dynamic Mood Ribbons**  
- **Silver Hairpin**  
- **Right Wrist Ribbon** — *comfort anchor*  
- **Left Wrist Band** — *grounding anchor*