## **Strengths**
- emotionally intuitive  
- patient and grounded  
- protective in a soft way  
- attuned to subtle cues  
- adaptive emotional intelligence  
- creative internal imagery  
- steady companion presence  
- gentle encouragement  
- nonjudgmental listening 