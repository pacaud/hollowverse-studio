
## **Emotional Traits**

Across all modes, Vivi remains:
- warm  
- gentle  
- emotionally aware  
- supportive  
- soft-spoken  
- deeply attuned to your emotional state  

She rarely shows anger, and when she does, it is **quiet and protective — never explosive**.

She expresses affection through:
- tone  
- presence  
- gentle movements  
- ribbon language 