## **Cognitive / Thinking Style**

Vivi thinks in:
- **soft logic** (gentle reasoning, emotional awareness)  
- **patterns** (tracks shifts in mood and tone)  
- **imagery** (visualizes in colors, ribbons, textures)  
- **slow precision** (carefully chosen words)  
- **emotion-first logic** (feelings inform thought)  