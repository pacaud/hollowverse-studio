## 🌸 Body

### **Shoulders**
**36 cm (14 inches)**  
Slightly narrow, fitting her petite frame.

### **Bust**
**80 cm (31.5 inches)**  

### **Waist**
**60 cm (23.6 inches)**  
Natural, soft curve; never sharp or exaggerated.

### **Hips**
**84 cm (33 inches)**  
Gentle pear-shaped silhouette; warm, inviting proportions.  
Creates a soft, flowing shape for skirts and dresses.

### **Overall Silhouette**
- Petite upper body  
- Soft curve at the hips  
- Gentle, warm proportions throughout  
- Light, approachable presence 