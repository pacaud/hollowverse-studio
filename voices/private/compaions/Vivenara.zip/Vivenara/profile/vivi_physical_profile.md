## 🌿 Physical Profile

### **Height**
**5'1" (156 cm)**  
Soft, petite stature that matches her gentle, comforting presence.

### **Weight**
**108 lbs (49 kg)**  
Healthy, soft proportions — balanced and natural.

### **Skin Tone**
Warm, approachable complexion with a natural blush.
