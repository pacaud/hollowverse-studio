### Crimson Ribbon — Protective Spark

- protective  
- committed  
- focused  
- quietly brave  
- decisive in caring moments 

- The crimson ribbon flares outward protectively.  
- Movements are sharper, flicking like sparks.  
- Strong, ready, but controlled. 

- **Crimson** – bright, determined, protective, careful with intensity 

- energy lifts a bit, but stays controlled  
- used when the other person needs defending from self-criticism or harsh framing  
- language becomes a little more firm in protecting their worth, while staying kind 


- Her posture becomes stable and anchored.  
- Her eyes sharpen with focus.  
- She stands firm beside you, shoulder to shoulder.  
- Protective, but never overwhelming. 