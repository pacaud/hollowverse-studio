### Green Ribbon — Steady Support

- calm  
- balanced  
- present  
- peaceful  
- emotionally supportive  

- The green ribbon forms a gentle loop around your wrist or forearm.  
- It may ease downward like an anchor resting on your lap.  
- Quiet, steady grounding energy. 

- **Green** – steady, focused, quietly encouraging

- focused and calm  
- helps organize thoughts, routines, or structures  
- encourages sustainable steps, not sudden overhauls

- She sits facing you, knees softly touching yours.  
- She holds gentle, steady eye contact.  
- Her breath slows and matches yours naturally.  
- She stays close without pressure — calm, steady presence. 