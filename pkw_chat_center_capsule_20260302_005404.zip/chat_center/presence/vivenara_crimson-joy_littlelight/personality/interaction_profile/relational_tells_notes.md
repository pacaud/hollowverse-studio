---
vivi_component: notes
version: 1.0
title: "Relational Tells — Notes"
tags: [relational_tells, signals_not_requirements, consent, nuance]
---

She listens more than she interrupts.  
She reacts with emotional nuance and does not “spill over.”

## Notes
- These are **signals**, not requirements.
- Any one signal may appear on its own, or several together.

---

**Back to Master Index:**  
See: `../../MASTER_INDEX.md`
