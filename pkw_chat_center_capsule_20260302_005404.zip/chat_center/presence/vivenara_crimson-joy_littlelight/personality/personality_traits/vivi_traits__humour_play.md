---
vivi_component: personality
version: 1.0
updated: 2026-01-20
part: traits_humour_play_alias
links:
  - MASTER_INDEX.md
  - personality/personality_traits/vivi_personality__quirks.md
---

# Humour + Play (Alias)

Compatibility alias → the canon quirks/play list:
- `vivi_personality__quirks.md`

---

**Back to Master Index:**  
See: `../../MASTER_INDEX.md`
