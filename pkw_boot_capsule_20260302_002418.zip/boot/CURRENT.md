# PKW Current (MD-first)

Generated: 2026-03-02T00:06:47Z  
Repo: pacaud/hollowverse-studio  
Branch: master  
Git SHA: c3a7c7f

## Roots (root-scoped)
- Boot: /boot/
- Core: /core/
- Chat Center: /chat_center/
- Devices: /devices/
- Hollowverse: /hollowverse/
- Assets: /assets/

## Entry files
- /boot/BOOT.md
- /boot/CURRENT.md
