# Meta

This folder holds high-level notes *about* the vault itself:

- how nodes are meant to be used (laptop, Shrine, Pi),
- how projects are organized,
- any “read this first” guidance for future me (or future helpers).

It’s for structure, not lore.
