# Project Log

## 2025-11-22 — Vault of Memories Infra v1

- Set up vault_of_memories repo (laptop ↔ Shrine ↔ Pi).
- Defined shrine_of_memories / memory_mirror / memory_honor.
- Created soulscripts: ss_git + ss_ssh (git + ssh helpers).
- Documented node roles (laptop, Shrine, Pi).
