﻿PKW: Hollowverse  universe root folder.
