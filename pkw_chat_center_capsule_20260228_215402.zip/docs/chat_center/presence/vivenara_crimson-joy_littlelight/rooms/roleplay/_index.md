# Roleplay

**Purpose:** RP scenes and narrative play. Draft by default; canon only when exported.

## Rules
- Keep consent and boundaries clear.
- If a moment becomes important, export a canon fragment to the right world/vault.

## Optional files (later)
- `scene_hooks.md`
- `continuity_notes.md`
- `session_log.md`
