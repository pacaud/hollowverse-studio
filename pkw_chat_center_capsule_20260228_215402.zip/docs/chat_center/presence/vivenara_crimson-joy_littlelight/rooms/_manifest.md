# _manifest

name: rooms
parent: vivenara_crimson-joy_littlelight
version: 0.0.13
updated: 2026-02-28

---

role:
Defines and contains the `rooms` layer of the Vivenara capsule.

---

stability:
- Additive changes allowed
- Major restructuring requires version bump
