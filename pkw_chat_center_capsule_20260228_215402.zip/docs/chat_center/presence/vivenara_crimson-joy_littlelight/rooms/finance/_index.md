# Finance

**Purpose:** Money planning: budgets, pricing, rates, subscriptions. Keep it simple for now.

## Rules
- Prefer human-readable notes over heavy formal structure.
- Expand later when Gild returns (if desired).

## Optional files (later)
- `budget.md`
- `pricing.md`
- `subscriptions.md`
