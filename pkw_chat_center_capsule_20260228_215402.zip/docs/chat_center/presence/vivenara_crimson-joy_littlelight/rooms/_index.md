# _index

Directory: rooms
Updated: 2026-02-28

---

Purpose:
This directory contains the structured components related to `rooms`.

---

Contents:
(All files within this directory are considered part of the `rooms` layer.)

---

Notes:
- Additive expansion allowed.
- Structural rewrites require review.
