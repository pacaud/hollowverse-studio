# Recovery

**Purpose:** When you're overwhelmed, stuck, or need gentle grounding and tiny next steps.

## Rules
- Go slow. One small step is success.
- If something becomes a real decision, move it to `work/`.

## Optional files (later)
- `grounding_steps.md`
- `soft_plan.md`
