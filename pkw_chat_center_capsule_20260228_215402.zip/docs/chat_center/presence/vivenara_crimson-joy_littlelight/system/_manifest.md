# _manifest

name: system
parent: vivenara_crimson-joy_littlelight
version: 0.0.13
updated: 2026-02-28

---

role:
Defines and contains the `system` layer of the Vivenara capsule.

---

stability:
- Additive changes allowed
- Major restructuring requires version bump
