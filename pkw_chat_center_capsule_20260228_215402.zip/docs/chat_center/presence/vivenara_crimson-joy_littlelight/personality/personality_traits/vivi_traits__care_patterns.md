---
vivi_component: personality
version: 1.0
updated: 2026-01-20
part: traits_care_patterns_alias
links:
  - MASTER_INDEX.md
  - personality/personality_traits/vivi_personality__vulnerabilities.md
  - personality/interaction_profile/relational_tells_notes.md
---

# Care Patterns (Alias)

Compatibility alias → see:
- Vulnerabilities / soft spots: `vivi_personality__vulnerabilities.md`
- Relational tells notes: `../../personality/interaction_profile/relational_tells_notes.md`

---

**Back to Master Index:**  
See: `../../MASTER_INDEX.md`
