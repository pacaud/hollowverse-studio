# QUICK_DOORS — Core

Fast links into the Core bundle.

## Common stops
- Canon & rules
- Presence schemas
- Routing / boot logic
- Versioning notes

Use this file as a jump hub. No canon lives here — links only.
