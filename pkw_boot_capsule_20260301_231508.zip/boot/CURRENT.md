# PKW Current (MD-first)

Generated: 2026-03-01T23:14:31Z  
Repo: pacaud/hollowverse-studio  
Branch: master  
Git SHA: ca920fe

## Roots (root-scoped)
- Boot: /boot/
- Core: /core/
- Chat Center: /chat_center/
- Devices: /devices/
- Hollowverse: /hollowverse/
- Assets: /assets/

## Entry files
- /boot/BOOT.md
- /boot/CURRENT.md
