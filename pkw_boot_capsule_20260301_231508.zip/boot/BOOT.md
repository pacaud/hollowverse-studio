# PKW Boot (MD-first)

Generated: 2026-03-01T23:14:31Z

This is the MD-first boot entrypoint for PKW / Hollowverse.
