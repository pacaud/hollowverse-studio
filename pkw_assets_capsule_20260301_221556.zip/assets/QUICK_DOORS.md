# QUICK_DOORS — Assets

Fast links into commonly used assets.

## Common stops
- Vivi body sheets
- Ribbons
- UI icons
- Decorative elements

This is a navigation file only.
