- click file -> open editor view

- simple save back to same path

- maybe “new file” button
