

# Voxia Schema Version
version: '0.5'

# Fallback
fallback: 'v0.3 supported for legacy systems'
