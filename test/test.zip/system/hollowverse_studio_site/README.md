Public studio site for hollowverse.studio. This folder holds the web root and config for deployment.

# Voxia Schema Version
version: '0.5'

# Fallback
fallback: 'v0.3 supported for legacy systems'
