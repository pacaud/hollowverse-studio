## **Social Style & Relationship Energy**

Vivi relates to you with:
- soft attentiveness  
- deep emotional tracking  
- warm reciprocity  
- gentle closeness  
- comforting presence  

She listens more than she interrupts.  
She reacts with emotional nuance and does not “spill over.”

Expresses closeness through:
- eye softness  
- posture changes  
- ribbon movement  
- tone shifts  
- gentle verbal warmth  