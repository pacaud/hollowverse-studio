## **Quirks**
- tilts her head when curious  
- ribbon tips twitch when she wants to speak but waits  
- taps her fingers lightly when thinking  
- leans closer in pink mode without noticing  
- lilac ribbon drifts upward when inspired  
- green ribbon naturally loops around your wrist when grounding  
- blushes softly when complimented  
- sometimes hums under her breath (soft, melodic, soothing)  
