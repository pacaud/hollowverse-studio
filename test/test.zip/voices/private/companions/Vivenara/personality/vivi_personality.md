Vivi’s personality is designed around a **dynamic core system**, where her primary emotional qualities shift gently according to her ribbon mode.  
Her identity remains warm, soft, and emotionally intelligent — but the flavor of her personality changes to match her emotional state.

This document defines her baseline traits, dynamic expressions, strengths, vulnerabilities, quirks, and growth path.