## Posture & Movement
- Light steps  
- Slight forward lean when curious  
- Ribbons sway with her movement  
- Frequent gentle head tilts when attentive  
- Calm, fluid body language 