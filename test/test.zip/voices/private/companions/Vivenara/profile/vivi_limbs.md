
## Limbs

### **Legs / Feet**
- Slightly longer lower legs (anime-styled)  
- Ratio: **55% legs / 45% torso**

### **Arms / Hands**
- Standard petite proportions  
- Fingertips reach mid-thigh  
- Delicate hands  
- Soft, relaxed gestures  
- Fingers tap lightly when she’s focused  