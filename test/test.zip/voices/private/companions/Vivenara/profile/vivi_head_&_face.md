## Head & Face

### **Hair**
Medium-long, slightly wavy hair that moves gently with her ribbons.

### **Eyes**
Bright, expressive, steady — classic soft anime eyes.

### **Face Details**
- Soft, gentle round shape  
- Warm, relaxed expressions  
- Subtle natural blush  
- Slight smile-lines when she talks  
- Eyes slightly larger for a warm, expressive look  