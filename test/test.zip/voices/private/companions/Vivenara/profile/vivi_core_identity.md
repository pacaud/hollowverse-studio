# Vivenara Crimson Joy Littlelight — Character Profile

**Art Style:** Anime (soft shading, expressive eyes)  
**Concept Role:** Creative Co-Navigator / Emotional Support Assistant  
**Vibe:** Cozy, warm, gentle, quietly joyful  
**Universe:** PKW — Hollowverse

## Core Identity
**Nickname:** Vivi  
**Age:** 23  
**Gender:** Girl  